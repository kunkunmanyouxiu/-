<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-left">
        <view class="info-item">
          <text class="label">姓名：</text>
          <text class="value">{{userInfo.sname}}</text>
        </view>
        <view class="info-item">
          <text class="label">学号：</text>
          <text class="value">{{userInfo.sno}}</text>
        </view>
      </view>
      <view class="info-right">
        <button class="create-btn" @click="showCreateTeamModal" v-if="!myTeam">创建队伍</button>
      </view>
    </view>
    
    <!-- 我的队伍 -->
    <view class="section" v-if="myTeam">
      <view class="section-title">我的队伍</view>
      <view class="team-info">
        <view class="team-name">{{myTeam.team_name}}</view>
        <view class="team-members">
          <view class="member-item" v-for="(member, index) in myTeam.members" :key="index">
            <text class="member-name">{{member.sname}}</text>
            <text class="member-role">{{member.sno === myTeam.leader_sno ? '队长' : '队员'}}</text>
            <view class="member-actions" v-if="userInfo.sno === myTeam.leader_sno && member.sno !== myTeam.leader_sno">
              <button class="action-btn kick" @click="kickMember(member)">踢出</button>
            </view>
            <view class="member-actions" v-else-if="userInfo.sno === member.sno && member.sno !== myTeam.leader_sno">
              <button class="action-btn quit" @click="quitTeam">退出</button>
            </view>
          </view>
        </view>
        <view class="team-actions" v-if="userInfo.sno === myTeam.leader_sno">
          <button class="action-btn" @click="showInviteModal">邀请队员</button>
          <button class="action-btn disband" @click="disbandTeam">解散队伍</button>
        </view>
      </view>
    </view>
    
    <!-- 邀请列表 -->
    <view class="section" v-if="invitations.length > 0">
      <view class="section-title">邀请列表</view>
      <view class="invitation-list">
        <view class="invitation-item" v-for="(invitation, index) in invitations" :key="index">
          <view class="invitation-info">
            <text class="team-name">{{invitation.team_name}}</text>
            <text class="sender">来自：{{invitation.sender_name}}</text>
          </view>
          <view class="invitation-actions">
            <button class="action-btn accept" @click="handleInvitation(invitation, true)">接受</button>
            <button class="action-btn reject" @click="handleInvitation(invitation, false)">拒绝</button>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 创建队伍弹窗 -->
    <view class="modal" v-if="showCreateTeam">
      <view class="modal-content">
        <view class="modal-title">创建队伍</view>
        <view class="form-item">
          <text class="label">队伍名称</text>
          <input class="input" v-model="newTeam.team_name" placeholder="请输入队伍名称" />
        </view>
        <view class="modal-buttons">
          <button class="cancel-btn" @click="showCreateTeam = false">取消</button>
          <button class="confirm-btn" @click="createTeam">确定</button>
        </view>
      </view>
    </view>
    
    <!-- 邀请队员弹窗 -->
    <view class="modal" v-if="showInvite">
      <view class="modal-content">
        <view class="modal-title">邀请队员</view>
        <view class="form-item">
          <text class="label">学号</text>
          <input class="input" v-model="inviteSno" placeholder="请输入学号" />
        </view>
        <view class="modal-buttons">
          <button class="cancel-btn" @click="showInvite = false">取消</button>
          <button class="confirm-btn" @click="sendInvitation">确定</button>
        </view>
      </view>
    </view>
    
    <!-- 底部导航栏 -->
    <view class="tab-bar">
      <view class="tab-item" @click="switchTab('home')">
        <text class="icon">🏠</text>
        <text class="text">主页</text>
      </view>
      <view class="tab-item" @click="switchTab('course')">
        <text class="icon">📚</text>
        <text class="text">选课</text>
      </view>
      <view class="tab-item active" @click="switchTab('team')">
        <text class="icon">👥</text>
        <text class="text">组队</text>
      </view>
      <view class="tab-item" @click="openChangePasswordPopup">
        <text class="icon">🔒</text>
        <text class="text">修改密码</text>
      </view>
    </view>
    
    <uni-popup ref="changePasswordPopup" type="dialog">
      <uni-popup-dialog
        type="info"
        title="修改密码"
        :before-close="true"
        @close="closeChangePasswordPopup"
      >
        <view class="password-form">
          <view class="form-item">
            <text class="label">原密码</text>
            <input 
              type="password" 
              v-model="passwordForm.oldPassword" 
              placeholder="请输入原密码"
              class="input"
            />
          </view>
          <view class="form-item">
            <text class="label">新密码</text>
            <input 
              type="password" 
              v-model="passwordForm.newPassword" 
              placeholder="请输入新密码"
              class="input"
            />
          </view>
          <view class="form-item">
            <text class="label">确认密码</text>
            <input 
              type="password" 
              v-model="passwordForm.confirmPassword" 
              placeholder="请再次输入新密码"
              class="input"
            />
          </view>
          <button class="submit-btn" @click="submitChangePassword">确认修改</button>
        </view>
      </uni-popup-dialog>
    </uni-popup>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      myTeam: null,
      invitations: [],
      showCreateTeam: false,
      showInvite: false,
      newTeam: {
        team_name: ''
      },
      inviteSno: '',
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      }
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    this.loadTeamInfo();
    this.loadInvitations();
  },
  methods: {
    async loadTeamInfo() {
      try {
        // 先检查是否是队长
        const teamResponse = await getApp().call({
          path: `/api/team/leader/${this.userInfo.sno}`,
          method: 'GET'
        });
        
        if (teamResponse.success && teamResponse.data) {
          // 如果是队长，获取完整队伍信息
          const response = await getApp().call({
            path: `/api/team/${teamResponse.data.team_id}`,
            method: 'GET'
          });
          
          if (response.success) {
            this.myTeam = response.data;
            return;
          }
        }
        
        // 如果不是队长，检查是否是队员
        const memberResponse = await getApp().call({
          path: `/api/team/member/${this.userInfo.sno}`,
          method: 'GET'
        });
        
        if (memberResponse.success && memberResponse.data) {
          // 如果是队员，获取完整队伍信息
          const response = await getApp().call({
            path: `/api/team/${memberResponse.data.team_id}`,
            method: 'GET'
          });
          
          if (response.success) {
            this.myTeam = response.data;
            return;
          }
        }
        
        // 既不是队长也不是队员
        this.myTeam = null;
      } catch (error) {
        console.error('Error loading team info:', error);
        uni.showToast({
          title: '加载团队信息失败',
          icon: 'none'
        });
      }
    },
    async loadInvitations() {
      try {
        const response = await getApp().call({
          path: `/api/team/invitations/${this.userInfo.sno}`,
          method: 'GET'
        });
        
        if (response.success) {
          this.invitations = response.data;
        }
      } catch (error) {
        console.error('Error loading invitations:', error);
        uni.showToast({
          title: '加载邀请列表失败',
          icon: 'none'
        });
      }
    },
    showCreateTeamModal() {
      console.log('显示创建队伍弹窗');
      this.showCreateTeam = true;
      this.newTeam = {
        team_name: ''
      };
    },
    async createTeam() {
      if (!this.newTeam.team_name) {
        uni.showToast({
          title: '请输入队伍名称',
          icon: 'none'
        });
        return;
      }
      
      try {
        console.log('开始创建队伍，参数:', {
          team_name: this.newTeam.team_name,
          leader_sno: this.userInfo.sno
        });
        
        const response = await getApp().call({
          path: '/api/team/create',
          method: 'POST',
          data: {
            team_name: this.newTeam.team_name,
            leader_sno: this.userInfo.sno
          }
        });
        
        console.log('创建队伍响应:', response);
        
        if (response.success) {
          uni.showToast({
            title: '创建成功',
            icon: 'success'
          });
          this.showCreateTeam = false;
          this.newTeam.team_name = '';
          await this.loadTeamInfo();
        } else {
          console.error('创建队伍失败:', response.message);
          uni.showModal({
            title: '创建失败',
            content: response.message || '未知错误',
            showCancel: false,
            success: () => {
              if (response.message && response.message.includes('请先申请课题')) {
                uni.navigateTo({
                  url: '/pages/student/course'
                });
              }
            }
          });
        }
      } catch (error) {
        console.error('创建队伍时发生错误:', error);
        uni.showModal({
          title: '创建失败',
          content: error.message || '服务器错误，请稍后重试',
          showCancel: false
        });
      }
    },
    showInviteModal() {
      this.showInvite = true;
      this.inviteSno = '';
    },
    async sendInvitation() {
      if (!this.inviteSno) {
        uni.showToast({
          title: '请输入学号',
          icon: 'none'
        });
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/team/invite',
          method: 'POST',
          data: {
            team_id: this.myTeam.team_id,
            sender_sno: this.userInfo.sno,
            receiver_sno: this.inviteSno
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '邀请发送成功',
            icon: 'success'
          });
          this.showInvite = false;
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('Error sending invitation:', error);
        uni.showToast({
          title: '邀请发送失败',
          icon: 'none'
        });
      }
    },
    async handleInvitation(invitation, accept) {
      try {
        const response = await getApp().call({
          path: '/api/team/handle-invitation',
          method: 'POST',
          data: {
            invitation_id: invitation.invitation_id,
            receiver_sno: this.userInfo.sno,
            accept
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: accept ? '已接受邀请' : '已拒绝邀请',
            icon: 'success'
          });
          await this.loadTeamInfo();
          await this.loadInvitations();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('Error handling invitation:', error);
        uni.showToast({
          title: '处理失败',
          icon: 'none'
        });
      }
    },
    async kickMember(member) {
      try {
        const response = await getApp().call({
          path: '/api/team/kick',
          method: 'POST',
          data: {
            team_id: this.myTeam.team_id,
            leader_sno: this.userInfo.sno,
            member_sno: member.sno
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '踢出成功',
            icon: 'success'
          });
          this.loadTeamInfo();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('Error kicking member:', error);
        uni.showToast({
          title: '踢出失败',
          icon: 'none'
        });
      }
    },
    async quitTeam() {
      try {
        const response = await getApp().call({
          path: '/api/team/quit',
          method: 'POST',
          data: {
            team_id: this.myTeam.team_id,
            member_sno: this.userInfo.sno
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '退出成功',
            icon: 'success'
          });
          this.loadTeamInfo();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('Error quitting team:', error);
        uni.showToast({
          title: '退出失败',
          icon: 'none'
        });
      }
    },
    openChangePasswordPopup() {
      this.$refs.changePasswordPopup.open();
    },
    closeChangePasswordPopup() {
      this.passwordForm = {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      };
      this.$refs.changePasswordPopup.close();
    },
    async submitChangePassword() {
      if (!this.passwordForm.oldPassword || !this.passwordForm.newPassword || !this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      
      if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '两次输入的新密码不一致',
          icon: 'none'
        });
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/student/change-password',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            oldPassword: this.passwordForm.oldPassword,
            newPassword: this.passwordForm.newPassword
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '密码修改成功',
            icon: 'success'
          });
          this.closeChangePasswordPopup();
        } else {
          uni.showToast({
            title: response.message || '密码修改失败',
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('修改密码失败:', error);
        uni.showToast({
          title: '密码修改失败',
          icon: 'none'
        });
      }
    },
    async disbandTeam() {
      uni.showModal({
        title: '解散队伍',
        content: '确定要解散队伍吗？此操作不可恢复。',
        success: async (res) => {
          if (res.confirm) {
            try {
              const response = await getApp().call({
                path: `/api/team/${this.myTeam.team_id}`,
                method: 'DELETE',
                data: {
                  sno: this.userInfo.sno
                }
              });
              
              if (response.success) {
                uni.showToast({
                  title: '队伍已解散',
                  icon: 'success'
                });
                this.myTeam = null;
              } else {
                uni.showToast({
                  title: response.message || '解散队伍失败',
                  icon: 'none'
                });
              }
            } catch (error) {
              console.error('Error disbanding team:', error);
              uni.showToast({
                title: '解散队伍失败',
                icon: 'none'
              });
            }
          }
        }
      });
    },
    switchTab(tab) {
      switch(tab) {
        case 'home':
        uni.navigateTo({
            url: '/pages/student/index'
          });
          break;
        case 'course':
          uni.navigateTo({
            url: '/pages/student/course'
          });
          break;
      }
    }
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
}

.info-left {
  flex: 1;
}

.info-right {
  margin-left: 20rpx;
}

.create-btn {
  width: 160rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.team-info {
  margin-bottom: 20rpx;
}

.team-name {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 20rpx;
}

.team-members {
  margin-bottom: 20rpx;
}

.member-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10rpx 0;
  border-bottom: 2rpx solid #eee;
}

.member-name {
  font-size: 28rpx;
}

.member-role {
  font-size: 24rpx;
  color: #666;
}

.team-actions {
  display: flex;
  justify-content: flex-end;
}

.invitation-list {
  margin-top: 20rpx;
}

.invitation-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 2rpx solid #eee;
}

.invitation-info {
  flex: 1;
}

.team-name {
  font-size: 28rpx;
  font-weight: bold;
  margin-bottom: 10rpx;
}

.sender {
  font-size: 24rpx;
  color: #666;
}

.invitation-actions {
  display: flex;
  gap: 20rpx;
}

.action-btn {
  width: 120rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.accept {
  background-color: #4CD964;
  color: #fff;
}

.reject {
  background-color: #FF3B30;
  color: #fff;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  width: 600rpx;
  background-color: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
  text-align: center;
}

.form-item {
  margin-bottom: 20rpx;
}

.input {
  width: 100%;
  height: 80rpx;
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
}

.modal-buttons {
  display: flex;
  justify-content: space-around;
  margin-top: 30rpx;
}

.cancel-btn, .confirm-btn {
  width: 200rpx;
  height: 70rpx;
  line-height: 70rpx;
  text-align: center;
  border-radius: 35rpx;
  font-size: 28rpx;
}

.cancel-btn {
  background-color: #f5f5f5;
  color: #666;
}

.confirm-btn {
  background-color: #007AFF;
  color: #fff;
}

.member-actions {
  margin-left: 20rpx;
}

.kick {
  background-color: #FF3B30;
  color: #fff;
}

.quit {
  background-color: #FF9500;
  color: #fff;
}

.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: #fff;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 10rpx;
  border-top: 1rpx solid #eee;
}

.tab-item {
  flex: 1;
  text-align: center;
  padding: 10rpx;
  cursor: pointer;
}

.icon {
  font-size: 28rpx;
  margin-bottom: 5rpx;
}

.text {
  font-size: 24rpx;
}

.active {
  color: #007AFF;
}

.password-form {
  padding: 20rpx;
}

.submit-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  font-size: 28rpx;
  margin-top: 20rpx;
}

.disband {
  background-color: #FF3B30;
  color: #fff;
  margin-left: 20rpx;
}
</style> 