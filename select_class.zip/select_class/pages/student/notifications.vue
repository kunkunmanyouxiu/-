<template>
  <view class="container">
    <view class="header">
      <text class="title">我的通知</text>
      <button class="read-all-btn" @click="markAllAsRead">全部已读</button>
    </view>
    
    <view class="notification-list">
      <view v-if="notifications.length === 0" class="empty-tip">
        暂无通知
      </view>
      
      <view v-else v-for="notification in notifications" :key="notification.id" 
            class="notification-item" :class="{ unread: !notification.is_read }">
        <view class="notification-content">
          <text class="message">{{ notification.message }}</text>
          <text class="time">{{ formatTime(notification.create_time) }}</text>
        </view>
        <view class="notification-actions">
          <button v-if="!notification.is_read" class="read-btn" @click="markAsRead(notification)">
            标记已读
          </button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      notifications: [],
      userInfo: {}
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    this.loadNotifications();
  },
  methods: {
    async loadNotifications() {
      try {
        const response = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/notifications`,
          method: 'GET'
        });
        
        if (response.success) {
          this.notifications = response.data;
        }
      } catch (error) {
        console.error('Error loading notifications:', error);
        uni.showToast({
          title: '加载通知失败',
          icon: 'none'
        });
      }
    },
    
    async markAsRead(notification) {
      try {
        const response = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/notifications/${notification.id}/read`,
          method: 'POST'
        });
        
        if (response.success) {
          notification.is_read = true;
          uni.showToast({
            title: '已标记为已读',
            icon: 'success'
          });
        }
      } catch (error) {
        console.error('Error marking notification as read:', error);
        uni.showToast({
          title: '操作失败',
          icon: 'none'
        });
      }
    },
    
    async markAllAsRead() {
      try {
        const response = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/notifications/read-all`,
          method: 'POST'
        });
        
        if (response.success) {
          this.notifications.forEach(notification => {
            notification.is_read = true;
          });
          uni.showToast({
            title: '已全部标记为已读',
            icon: 'success'
          });
        }
      } catch (error) {
        console.error('Error marking all notifications as read:', error);
        uni.showToast({
          title: '操作失败',
          icon: 'none'
        });
      }
    },
    
    formatTime(time) {
      const date = new Date(time);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    }
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx;
  background-color: #fff;
  border-radius: 10rpx;
  margin-bottom: 20rpx;
}

.title {
  font-size: 36rpx;
  font-weight: bold;
}

.read-all-btn {
  font-size: 28rpx;
  color: #007AFF;
  background: none;
  border: none;
  padding: 10rpx 20rpx;
}

.notification-list {
  background-color: #fff;
  border-radius: 10rpx;
  padding: 20rpx;
}

.notification-item {
  padding: 20rpx;
  border-bottom: 1rpx solid #eee;
}

.notification-item.unread {
  background-color: #f8f8f8;
}

.notification-content {
  margin-bottom: 10rpx;
}

.message {
  font-size: 32rpx;
  color: #333;
  margin-bottom: 10rpx;
  display: block;
}

.time {
  font-size: 24rpx;
  color: #999;
}

.notification-actions {
  display: flex;
  justify-content: flex-end;
}

.read-btn {
  font-size: 28rpx;
  color: #007AFF;
  background: none;
  border: none;
  padding: 10rpx 20rpx;
}

.empty-tip {
  text-align: center;
  color: #999;
  padding: 40rpx 0;
}
</style> 