<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-left">
        <view class="info-item">
          <text class="label">姓名：</text>
          <text class="value">{{userInfo.sname || '未设置'}}</text>
        </view>
        <view class="info-item">
          <text class="label">学号：</text>
          <text class="value">{{userInfo.sno || '未设置'}}</text>
        </view>
        <view class="info-item">
          <text class="label">班级：</text>
          <text class="value">{{userInfo.cname || '未设置'}}</text>
        </view>
        <view class="info-item time-info" v-if="courseTimeLimit.startTime && courseTimeLimit.endTime">
          <text class="label">选课时间：</text>
          <text class="value time-value">{{formatTime(courseTimeLimit.startTime)}} 至 {{formatTime(courseTimeLimit.endTime)}}</text>
        </view>
        <view class="info-item time-info" v-else>
          <text class="label">选课时间：</text>
          <text class="value time-value">未设置</text>
        </view>
      </view>
      <view class="info-right">
        <button class="apply-btn" @click="showNewTitleModal = true">申请新课题</button>
      </view>
    </view>
    
    <!-- 已选课题 -->
    <view class="section">
      <view class="section-title">已选课题</view>
      <view class="course-list">
        <view class="course-item" v-for="(course, index) in selectedCourses" :key="index">
          <view class="course-info">
            <text class="course-name">{{course.titlename}}</text>
            <text class="course-teacher">教师：{{course.tname}}</text>
            <text class="course-type">{{course.type === 'teacher' ? '教师设置' : '学生申请'}}</text>
            <text class="course-status" v-if="course.class_tt == 2">待审核</text>
            <text class="course-status" v-else-if="course.class_tt == 3">已通过</text>
          </view>
          <view class="course-actions">
            <button class="action-btn" @click="quitCourse(course)">退出</button>
          </view>
          <!-- 上传文件功能 -->
          <!-- <view class="upload-section">
            <button class="upload-btn" @click="chooseFile(course)">上传文件</button>
            <view class="file-list" v-if="course.files && course.files.length">
              <view class="file-item" v-for="file in course.files" :key="file.id">
                <text>{{file.file_name}}</text>
                <button size="mini" @click="downloadFile(file)">下载</button>
                <button size="mini" type="warn" @click="deleteFile(file, course)">删除</button>
              </view>
            </view>
          </view> -->
          <!-- 上传链接功能 -->
          <view class="link-section">
            <input v-model="course.linkInput" placeholder="请输入作品链接" class="link-input" />
            <button class="link-btn" @click="submitLink(course)">提交链接</button>
            <view v-if="course.link_url" class="link-show">
              <text>已提交链接：</text>
              <a :href="course.link_url" target="_blank">{{course.link_url}}</a>
            </view>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 可选课题 -->
    <view class="section">
      <view class="section-title">可选课题</view>
      <view class="course-list">
        <view class="course-item" v-for="(course, index) in availableCourses" :key="index">
          <view class="course-info">
            <text class="course-name">{{course.titlename}}</text>
            <text class="course-teacher">教师：{{course.tname}}</text>
            <text class="course-type">{{course.type == 'teacher' ? '教师设置' : '学生申请'}}</text>
          </view>
          <view class="course-actions">
            <button class="action-btn" @click="selectCourse(course)">选择</button>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 申请新课题弹窗 -->
    <view class="modal" v-if="showNewTitleModal">
      <view class="modal-content">
        <view class="modal-title">申请新课题</view>
        <view class="modal-body">
          <view class="form-item">
            <text class="label">课题名称</text>
            <input 
              v-model="newTitle.titlename" 
              class="input" 
              placeholder="请输入课题名称"
            />
          </view>
          <view class="form-item">
            <text class="label">教师编号</text>
            <input 
              v-model="newTitle.tno" 
              class="input" 
              placeholder="请输入教师编号"
            />
          </view>
        </view>
        <view class="modal-footer">
          <button class="modal-btn cancel" @click="closeNewTitleModal">取消</button>
          <button class="modal-btn confirm" @click="submitNewTitle">提交申请</button>
        </view>
      </view>
    </view>
    
    <!-- 底部导航栏 -->
    <view class="tab-bar">
      <view class="tab-item" @click="switchTab('home')">
        <text class="icon">🏠</text>
        <text class="text">主页</text>
      </view>
      <view class="tab-item active" @click="switchTab('course')">
        <text class="icon">📚</text>
        <text class="text">选课</text>
      </view>
      <view class="tab-item" @click="switchTab('team')">
        <text class="icon">👥</text>
        <text class="text">组队</text>
</view>
      <view class="tab-item" @click="openChangePasswordPopup">
        <text class="icon">🔒</text>
        <text class="text">修改密码</text>
      </view>
    </view>
    <uni-popup ref="reselectPopup" type="dialog">
  <uni-popup-dialog
    type="info"
    title="申请重新选题"
    content="选题时间已过，是否申请重新选题权限？"
    :before-close="true"
    @confirm="submitReselectRequest"
    @close="closeReselectPopup"
  >
    <view class="reselect-form">
      <textarea
        v-model="reselectReason"
        placeholder="请输入申请原因"
        class="reason-input"
      />
    </view>
  </uni-popup-dialog>
</uni-popup>
<uni-popup ref="changePasswordPopup" type="dialog">
  <uni-popup-dialog
    type="info"
    title="修改密码"
    :before-close="true"
    @close="closeChangePasswordPopup"
  >
    <view class="password-form">
      <view class="form-item">
        <text class="label">原密码</text>
        <input 
          type="password" 
          v-model="passwordForm.oldPassword" 
          placeholder="请输入原密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">新密码</text>
        <input 
          type="password" 
          v-model="passwordForm.newPassword" 
          placeholder="请输入新密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">确认密码</text>
        <input 
          type="password" 
          v-model="passwordForm.confirmPassword" 
          placeholder="请再次输入新密码"
          class="input"
        />
      </view>
      <button class="submit-btn" @click="submitChangePassword">确认修改</button>
    </view>
  </uni-popup-dialog>
</uni-popup>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      selectedCourses: [],
      availableCourses: [],
      showNewTitleModal: false,
      newTitle: {
        titlename: '',
        tno: ''
      },
      titles: [],
      selectedTitle: null,
      videoUrl: '',
      selectedFile: null,
      loading: false,
      reselectReason: '',
      currentTitle: null,
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      },
      courseTimeLimit: {
        startTime: null,
        endTime: null
      }
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    console.log('用户信息:', this.userInfo);
    
    if (!this.userInfo || !this.userInfo.sno) {
      uni.showToast({
        title: '请先登录',
        icon: 'none'
      });
      setTimeout(() => {
        uni.reLaunch({
          url: '/pages/login/login'
        });
      }, 1500);
      return;
    }
    
    // 通过班级号查找教师号
    this.findTeacherByClass().then(() => {
      Promise.all([
        this.loadCourseTimeLimit(),
        this.loadCourses(),
        this.loadTitles()
      ]).then(() => {
        console.log('选课时间限制:', this.courseTimeLimit);
      }).catch(error => {
        console.error('加载数据失败:', error);
      });
    }).catch(error => {
      console.error('查找教师失败:', error);
      uni.showToast({
        title: '无法获取教师信息',
        icon: 'none'
      });
    });
  },
  methods: {
    formatTime(time) {
      if (!time) return '';
      const date = new Date(time);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    },
    async loadCourseTimeLimit() {
      try {
        console.log('开始加载选课时间限制，教师号:', this.userInfo.tno);
        if (!this.userInfo.tno) {
          console.error('教师号不存在');
          return;
        }
        
        const response = await getApp().call({
          path: `/api/teacher/${this.userInfo.tno}/time-setting`,
          method: 'GET'
        });
        
        console.log('选课时间限制响应:', response);
        
        if (!response) {
          console.error('接口返回为空');
          return;
        }
        
        if (!response.success) {
          console.error('接口调用失败:', response.message);
          return;
        }
        
        if (!response.data) {
          console.error('接口返回数据为空');
          return;
        }
        
        console.log('原始时间数据:', response.data);
        
        // 确保时间字符串不为空
        if (response.data.startTime && response.data.endTime) {
          this.courseTimeLimit = {
            startTime: new Date(response.data.startTime),
            endTime: new Date(response.data.endTime)
          };
          console.log('转换后的时间数据:', this.courseTimeLimit);
        } else {
          console.warn('时间数据不完整');
          this.courseTimeLimit = {
            startTime: null,
            endTime: null
          };
        }
      } catch (error) {
        console.error('加载选课时间限制失败:', error);
        this.courseTimeLimit = {
          startTime: null,
          endTime: null
        };
      }
    },
    
    checkCourseTime() {
      const now = new Date();
      const startTime = new Date(this.courseTimeLimit.startTime);
      const endTime = new Date(this.courseTimeLimit.endTime);
      
      if (now < startTime) {
        uni.showToast({
          title: '选课时间未开始',
          icon: 'none'
        });
        return false;
      }
      
      if (now > endTime) {
        this.currentTitle = null;
        this.$refs.reselectPopup.open();
        return false;
      }
      
      return true;
    },
    
    async loadCourses() {
      try {
        // 获取已选课题
        const selectedResponse = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/courses`,
          method: 'GET'
        });
        
        if (selectedResponse.success) {
          this.selectedCourses = selectedResponse.data;
          // 加载每个课题的文件和链接
          for (const course of this.selectedCourses) {
            await this.loadFiles(course);
            course.linkInput = '';
          }
        }
        
        // 获取可选课题
        const availableResponse = await getApp().call({
          path: '/api/title/available',
          method: 'GET'
        });
        
        if (availableResponse.success) {
          this.availableCourses = availableResponse.data;
        }
      } catch (error) {
        uni.showToast({
          title: '加载课题列表失败',
          icon: 'none'
        });
      }
    },
    async loadFiles(course) {
      try {
        const res = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/title/${course.titlename}/files`,
          method: 'GET'
        });
        if (res.success) {
          course.files = res.data;
        } else {
          course.files = [];
        }
      } catch (e) {
        course.files = [];
      }
    },
    async selectCourse(course) {
      if (!this.checkCourseTime()) {
        // 如果选课时间已过，使用当前点击的课题作为重选申请的课题
        this.currentTitle = course.titlename;
        this.$refs.reselectPopup.open();
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/student/select-title',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            titlename: course.titlename,
            tname: course.tname
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '选课成功',
            icon: 'success'
          });
          this.loadCourses();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        uni.showToast({
          title: '选课失败',
          icon: 'none'
        });
      }
    },
    async quitCourse(course) {
      try {
        const response = await getApp().call({
          path: '/api/student/quit-title',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            titlename: course.titlename
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '退出成功',
            icon: 'success'
          });
          this.loadCourses();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        uni.showToast({
          title: '退出失败',
          icon: 'none'
        });
      }
    },
    closeNewTitleModal() {
      this.showNewTitleModal = false;
      this.newTitle = {
        titlename: '',
        tno: ''
      };
    },
    async submitNewTitle() {
      if (!this.newTitle.titlename || !this.newTitle.tno) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/student/apply-title',
          method: 'POST',
          data: {
            titlename: this.newTitle.titlename,
            tno: this.newTitle.tno,
            sno: this.userInfo.sno
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '申请提交成功',
            icon: 'success'
          });
          this.closeNewTitleModal();
          this.loadCourses();
        } else {
          uni.showToast({
            title: response.message,
            icon: 'none'
          });
        }
      } catch (error) {
        uni.showToast({
          title: '申请提交失败',
          icon: 'none'
        });
      }
    },
    switchTab(tab) {
      switch(tab) {
        case 'home':
        uni.navigateTo({
            url: '/pages/student/index'
          });
          break;
        case 'team':
          uni.navigateTo({
            url: '/pages/student/team'
          });
          break;
      }
    },
    async loadTitles() {
      try {
        const response = await getApp().call({
          path: '/api/title/all',
          method: 'GET'
        });
        
        if (response.success) {
          this.titles = response.data;
        }
      } catch (error) {
        uni.showToast({
          title: '加载课题列表失败',
          icon: 'none'
        });
      }
    },
    chooseFile(course) {
  uni.chooseFile({
    count: 1,
    success: async (res) => {
      if (res.tempFiles && res.tempFiles.length > 0) {
        const file = res.tempFiles[0];
        // 使用云托管方式上传文件
        const response = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/title/${course.titlename}/upload-file`,
          method: 'POST',
          filePath: file.path,
          name: 'file'
        });
        
        if (response.success) {
          uni.showToast({ title: '上传成功', icon: 'success' });
          this.loadFiles(course);
        } else {
          uni.showToast({ title: response.message || '上传失败', icon: 'none' });
        }
      }
    },
    fail: () => {
      uni.showToast({ title: '未选择文件', icon: 'none' });
    }
  });
},
downloadFile(file) {
  // 使用云托管方式下载文件
  getApp().call({
    path: `/api/student/file/${file.id}/download`,
    method: 'GET',
    responseType: 'blob'
  }).then(response => {
    if (response.success) {
      // 处理文件下载
      const filePath = response.data;
      uni.openDocument({
        filePath: filePath,
        showMenu: true
      });
    } else {
      uni.showToast({ title: response.message || '下载失败', icon: 'none' });
    }
  }).catch(() => {
    uni.showToast({ title: '下载失败', icon: 'none' });
  });
},
    async deleteFile(file, course) {
      uni.showLoading({ title: '删除中...' });
      try {
        const res = await getApp().call({
          path: `/api/student/file/${file.id}`,
          method: 'DELETE'
        });
        if (res.success) {
          uni.showToast({ title: '删除成功', icon: 'success' });
          this.loadFiles(course);
        } else {
          uni.showToast({ title: res.message || '删除失败', icon: 'none' });
        }
      } catch (e) {
        uni.showToast({ title: '删除失败', icon: 'none' });
      } finally {
        uni.hideLoading();
      }
    },
    async submitLink(course) {
      if (!course.linkInput || !/^https?:\/\//.test(course.linkInput)) {
        uni.showToast({ title: '请输入有效的链接', icon: 'none' });
        return;
      }
      try {
        const res = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/title/${course.titlename}/submit-link`,
          method: 'POST',
          data: { link_url: course.linkInput }
        });
        if (res.success) {
          uni.showToast({ title: '提交成功', icon: 'success' });
          course.link_url = course.linkInput;
          course.linkInput = '';
        } else {
          uni.showToast({ title: res.message || '提交失败', icon: 'none' });
        }
      } catch (e) {
        uni.showToast({ title: '提交失败', icon: 'none' });
      }
    },
    // 提交重选申请
    async submitReselectRequest() {
      if (!this.reselectReason.trim()) {
        uni.showToast({
          title: '请输入申请原因',
          icon: 'none'
        });
        return;
      }

      if (!this.currentTitle) {
        uni.showToast({
          title: '请先选择一个课题',
          icon: 'none'
        });
        return;
      }

      try {
        const response = await getApp().call({
          path: '/api/student/apply-reselect',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            titlename: this.currentTitle,
            reason: this.reselectReason
          }
        });

        if (response.success) {
          uni.showToast({
            title: '申请已提交',
            icon: 'success'
          });
          this.closeReselectPopup();
        } else {
          uni.showToast({
            title: response.message || '申请提交失败',
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('提交申请失败:', error);
        uni.showToast({
          title: '申请提交失败',
          icon: 'none'
        });
      }
    },

    // 关闭重选申请弹窗
    closeReselectPopup() {
      this.reselectReason = '';
      this.currentTitle = null;
      this.$refs.reselectPopup.close();
    },
    // 打开修改密码弹窗
    openChangePasswordPopup() {
      this.$refs.changePasswordPopup.open();
    },
    
    // 关闭修改密码弹窗
    closeChangePasswordPopup() {
      this.passwordForm = {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      };
      this.$refs.changePasswordPopup.close();
    },
    
    // 提交修改密码
    async submitChangePassword() {
      if (!this.passwordForm.oldPassword || !this.passwordForm.newPassword || !this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      
      if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '两次输入的新密码不一致',
          icon: 'none'
        });
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/student/change-password',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            oldPassword: this.passwordForm.oldPassword,
            newPassword: this.passwordForm.newPassword
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '密码修改成功',
            icon: 'success'
          });
          this.closeChangePasswordPopup();
        } else {
          uni.showToast({
            title: response.message || '密码修改失败',
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('修改密码失败:', error);
        uni.showToast({
          title: '密码修改失败',
          icon: 'none'
        });
      }
    },
    async findTeacherByClass() {
      try {
        console.log('开始查找教师，班级号:', this.userInfo.cno);
        const response = await getApp().call({
          path: `/api/student/${this.userInfo.sno}/teacher`,
          method: 'GET'
        });
        
        console.log('查找教师响应:', response);
        
        if (response.success && response.data) {
          this.userInfo.tno = response.data.tno;
          console.log('找到教师号:', this.userInfo.tno);
        } else {
          throw new Error('未找到对应的教师');
        }
      } catch (error) {
        console.error('查找教师失败:', error);
        throw error;
      }
    }
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
}

.info-left {
  flex: 1;
  margin-right: 20rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
  align-items: center;
}

.info-item .label {
  color: #666;
  width: 120rpx;
  font-size: 28rpx;
}

.info-item .value {
  color: #333;
  font-size: 28rpx;
  flex: 1;
  word-break: break-all;
}

.info-right {
  display: flex;
  align-items: center;
}

.apply-btn {
  width: 200rpx;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  font-size: 28rpx;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.course-list {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
}

.course-item {
  border-bottom: 2rpx solid #eee;
  padding: 20rpx 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.course-info {
  flex: 1;
}

.course-name {
  font-size: 32rpx;
  margin-bottom: 10rpx;
}

.course-teacher {
  font-size: 24rpx;
  color: #666;
}

.course-type {
  font-size: 24rpx;
  color: #666;
}

.course-actions {
  margin-left: 20rpx;
}

.course-status {
  font-size: 24rpx;
  color: #ff9500;
  margin-left: 10rpx;
}

.action-btn {
  width: 120rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.modal-content {
  width: 600rpx;
  background-color: #fff;
  border-radius: 20rpx;
  overflow: hidden;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  text-align: center;
  padding: 30rpx;
  border-bottom: 2rpx solid #eee;
}

.modal-body {
  padding: 30rpx;
}

.form-item {
  margin-bottom: 20rpx;
}

.input {
  width: 100%;
  height: 80rpx;
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
}

.modal-footer {
  display: flex;
  border-top: 2rpx solid #eee;
}

.modal-btn {
  flex: 1;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  font-size: 28rpx;
}

.modal-btn.cancel {
  background-color: #f5f5f5;
  color: #666;
}

.modal-btn.confirm {
  background-color: #007AFF;
  color: #fff;
}

.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100rpx;
  background-color: #fff;
  display: flex;
  justify-content: space-around;
  align-items: center;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.tab-item.active {
  color: #007AFF;
}

.icon {
  font-size: 40rpx;
  margin-bottom: 4rpx;
}

.text {
  font-size: 24rpx;
}

.upload-section { margin-top: 10rpx; }
.upload-btn { margin-bottom: 10rpx; }
.file-list { margin-bottom: 10rpx; }
.file-item { display: flex; align-items: center; gap: 10rpx; margin-bottom: 4rpx; }
.link-section { margin-top: 10rpx; display: flex; align-items: center; gap: 10rpx; }
.link-input { flex: 1; border: 1px solid #eee; border-radius: 8rpx; padding: 0 10rpx; height: 60rpx; }
.link-btn { height: 60rpx; }
.link-show { margin-top: 4rpx; color: #007AFF; }
.info-item.time-info {
  background-color: #f8f9fa;
  padding: 10rpx 20rpx;
  border-radius: 10rpx;
  margin-top: 10rpx;
}

.info-item.time-info .label {
  color: #007AFF;
  font-weight: bold;
}

.info-item.time-info .time-value {
  color: #333;
  font-weight: bold;
}
</style> 