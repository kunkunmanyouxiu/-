<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-left">
        <view class="info-item">
          <text class="label">姓名：</text>
          <text class="value">{{userInfo.sname}}</text>
        </view>
        <view class="info-item">
          <text class="label">学号：</text>
          <text class="value">{{userInfo.sno}}</text>
        </view>
        <view class="info-item">
          <text class="label">班级：</text>
          <text class="value">{{userInfo.cname}}</text>
        </view>
      </view>
      <view class="info-right">
        <button class="logout-btn" @click="logout">退出登录</button>
      </view>
    </view>
    
    <!-- 已选课程列表 -->
    <view class="course-list">
      <view class="section-title">已选课程</view>
      <view class="course-item" v-for="(course, index) in selectedCourses" :key="index">
        <view class="course-info">
          <view class="course-name">{{course.titlename}}</view>
          <view class="course-status" 
            :class="{
              'status-pending': course.status === 'pending' && course.class_tt === 2,
              'status-approved': course.status === 'approved' || (course.status === 'pending' && course.class_tt === 1)
            }">
            {{course.status === 'pending' && course.class_tt === 2 ? '待审核' : '已通过'}}
          </view>
        </view>
        <view class="course-actions" v-if="course.status === 'approved' || (course.status === 'pending' && course.class_tt === 1)">
          <button class="action-btn" @click="uploadFile(course)">上传文件</button>
          <button class="action-btn" @click="uploadVideo(course)">上传视频</button>
          <button class="action-btn" @click="addLink(course)">添加链接</button>
        </view>
      </view>
    </view>
    
    <!-- 底部导航栏 -->
    <view class="tab-bar">
      <view class="tab-item active" @click="switchTab('home')">
        <text class="icon">🏠</text>
        <text class="text">主页</text>
      </view>
      <view class="tab-item" @click="switchTab('course')">
        <text class="icon">📚</text>
        <text class="text">选课</text>
      </view>
      <view class="tab-item" @click="switchTab('team')">
        <text class="icon">👥</text>
        <text class="text">组队</text>
      </view>
      <view class="tab-item" @click="openChangePasswordPopup">
        <text class="icon">🔒</text>
        <text class="text">修改密码</text>
      </view>
    </view>

    <uni-popup ref="changePasswordPopup" type="dialog">
      <uni-popup-dialog
        type="info"
        title="修改密码"
        :before-close="true"
        @close="closeChangePasswordPopup"
      >
        <view class="password-form">
          <view class="form-item">
            <text class="label">原密码</text>
            <input 
              type="password" 
              v-model="passwordForm.oldPassword" 
              placeholder="请输入原密码"
              class="input"
            />
          </view>
          <view class="form-item">
            <text class="label">新密码</text>
            <input 
              type="password" 
              v-model="passwordForm.newPassword" 
              placeholder="请输入新密码"
              class="input"
            />
          </view>
          <view class="form-item">
            <text class="label">确认密码</text>
            <input 
              type="password" 
              v-model="passwordForm.confirmPassword" 
              placeholder="请再次输入新密码"
              class="input"
            />
          </view>
          <button class="submit-btn" @click="submitChangePassword">确认修改</button>
        </view>
      </uni-popup-dialog>
    </uni-popup>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      selectedCourses: [],
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      }
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    this.loadSelectedCourses();
  },
  onShow() {
    // 每次页面显示时刷新数据
    this.loadSelectedCourses();
  },
  onBackPress() {
    // 从其他页面返回时刷新数据
    this.loadSelectedCourses();
    return false;
  },
  methods: {
    async handleLogin() {
  if (!this.username || !this.password) {
    uni.showToast({
      title: '请输入账号和密码',
      icon: 'none'
    });
    return;
  }
  
  try {
    const response = await getApp().call({
      path: `/api/${this.activeRole}/login`,
      method: 'POST',
      data: {
        [this.activeRole === 'student' ? 'sno' : 'tno']: this.username,
        [this.activeRole === 'student' ? 'spwd' : 'tpwd']: this.password
      }
    });
    
    console.log('登录响应:', response); // 添加日志，方便调试
    
    if (response.success) {
      // 保存用户信息
      uni.setStorageSync('userInfo', response.data);
      uni.setStorageSync('role', this.activeRole);
      
      // 跳转到对应页面
      if (this.activeRole === 'student') {
        uni.reLaunch({
          url: '/pages/student/index'
        });
      } else {
        uni.navigateTo({
          url: '/pages/teacher/index'
        });
      }
    } else {
      uni.showToast({
        title: response.message || '登录失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('登录失败:', error); // 添加错误日志
    uni.showToast({
      title: '登录失败，请稍后重试',
      icon: 'none'
    });
  }
},
    switchTab(tab) {
      switch(tab) {
        case 'course':
          uni.navigateTo({
            url: '/pages/student/course'
          });
          break;
        case 'team':
          uni.navigateTo({
            url: '/pages/student/team'
          });
          break;
      }
    },
    uploadFile(course) {
  uni.chooseFile({
    count: 1,
    success: async (res) => {
      if (res.tempFiles && res.tempFiles.length > 0) {
        const file = res.tempFiles[0];
        try {
          const response = await getApp().call({
            path: `/api/student/${this.userInfo.sno}/title/${course.titlename}/upload-file`,
            method: 'POST',
            filePath: file.path,
            name: 'file'
          });
          
          if (response.success) {
            uni.showToast({ title: '上传成功', icon: 'success' });
            this.loadSelectedCourses();
          } else {
            uni.showToast({ title: response.message || '上传失败', icon: 'none' });
          }
        } catch (error) {
          console.error('Upload failed:', error);
          uni.showToast({ title: '上传失败', icon: 'none' });
        }
      }
    },
    fail: () => {
      uni.showToast({ title: '未选择文件', icon: 'none' });
    }
  });
},
async uploadVideo(course) {
  try {
    // 选择视频文件
    const res = await uni.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 600,
      camera: 'back'
    });
    
    if (!res || !res.tempFilePath) {
      uni.showToast({
        title: '请选择视频文件',
        icon: 'none'
      });
      return;
    }
    
    // 显示上传进度
    uni.showLoading({
      title: '上传中...'
    });
    
    // 使用云托管方式上传视频
    const response = await getApp().call({
      path: `/api/teacher/${course.tno}/title/${course.titlename}/submit-video`,
      method: 'POST',
      filePath: res.tempFilePath,
      name: 'video',
      formData: {
        sno: this.userInfo.sno
      }
    });
    
    if (response.success) {
      uni.showToast({
        title: '上传成功',
        icon: 'success'
      });
      // 刷新课题信息
      this.loadSelectedCourses();
    } else {
      uni.showToast({
        title: response.message || '上传失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error in uploadVideo:', error);
    uni.showToast({
      title: '上传失败',
      icon: 'none'
    });
  } finally {
    uni.hideLoading();
  }
},
addLink(course) {
  uni.showModal({
    title: '添加链接',
    editable: true,
    placeholderText: '请输入作品链接或小程序路径',
    success: async (res) => {
      if (res.confirm) {
        const link = res.content && res.content.trim();
        if (!link) {
          uni.showToast({ title: '链接不能为空', icon: 'none' });
          return;
        }
        // 允许 http(s)、pages/、#小程序:// 开头
        if (
          !/^https?:\/\//.test(link) &&
          !/^pages\//.test(link) &&
          !/^#小程序:\/\//.test(link)
        ) {
          uni.showToast({ title: '请输入有效的网页链接或小程序路径', icon: 'none' });
          return;
        }
        try {
          const response = await getApp().call({
            path: `/api/student/${this.userInfo.sno}/title/${course.titlename}/submit-link`,
            method: 'POST',
            data: { link_url: link }
          });
          
          if (response.success) {
            uni.showToast({ title: '提交成功', icon: 'success' });
            this.loadSelectedCourses();
          } else {
            uni.showToast({ title: response.message || '提交失败', icon: 'none' });
          }
        } catch (error) {
          console.error('Submit link failed:', error);
          uni.showToast({ title: '提交失败', icon: 'none' });
        }
      }
    }
  });
},
    logout() {
      uni.showModal({
        title: '提示',
        content: '确定要退出登录吗？',
        success: (res) => {
          if (res.confirm) {
            // 清除本地存储的用户信息
            uni.removeStorageSync('userInfo');
            // 跳转到登录页面
            uni.reLaunch({
              url: '/pages/login/login'
            });
          }
        }
      });
    },
    async loadSelectedCourses() {
  try {
    const response = await getApp().call({
      path: `/api/student/${this.userInfo.sno}/courses`,
      method: 'GET'
    });
    
    if (response.success) {
      this.selectedCourses = response.data;
    } else {
      uni.showToast({
        title: response.message || '加载课程列表失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error loading selected courses:', error);
    uni.showToast({
      title: '加载课程列表失败',
      icon: 'none'
    });
  }
},
    openChangePasswordPopup() {
      this.$refs.changePasswordPopup.open();
    },
    closeChangePasswordPopup() {
      this.passwordForm = {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      };
      this.$refs.changePasswordPopup.close();
    },
    async submitChangePassword() {
      if (!this.passwordForm.oldPassword || !this.passwordForm.newPassword || !this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '请填写完整信息',
          icon: 'none'
        });
        return;
      }
      
      if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
        uni.showToast({
          title: '两次输入的新密码不一致',
          icon: 'none'
        });
        return;
      }
      
      try {
        const response = await getApp().call({
          path: '/api/student/change-password',
          method: 'POST',
          data: {
            sno: this.userInfo.sno,
            oldPassword: this.passwordForm.oldPassword,
            newPassword: this.passwordForm.newPassword
          }
        });
        
        if (response.success) {
          uni.showToast({
            title: '密码修改成功',
            icon: 'success'
          });
          this.closeChangePasswordPopup();
        } else {
          uni.showToast({
            title: response.message || '密码修改失败',
            icon: 'none'
          });
        }
      } catch (error) {
        console.error('修改密码失败:', error);
        uni.showToast({
          title: '密码修改失败',
          icon: 'none'
        });
      }
    }
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
}

.info-left {
  flex: 1;
}

.info-right {
  margin-left: 20rpx;
}

.logout-btn {
  width: 160rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #FF3B30;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.course-list {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.course-item {
  border-bottom: 2rpx solid #eee;
  padding: 20rpx 0;
}

.course-info {
  flex: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.course-name {
  font-size: 32rpx;
  margin-bottom: 20rpx;
}

.course-status {
  font-size: 24rpx;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
}

.status-pending {
  background-color: #FFE4B5;
  color: #FF8C00;
}

.status-approved {
  background-color: #E6FFE6;
  color: #008000;
}

.course-actions {
  display: flex;
  justify-content: space-around;
}

.action-btn {
  width: 30%;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100rpx;
  background-color: #fff;
  display: flex;
  justify-content: space-around;
  align-items: center;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.tab-item.active {
  color: #007AFF;
}

.icon {
  font-size: 40rpx;
  margin-bottom: 4rpx;
}

.text {
  font-size: 24rpx;
}
</style> 