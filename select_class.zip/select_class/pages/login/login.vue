<template>
  <view class="login-container">
    <view class="login-header">
      <text class="title">自主选课系统</text>
    </view>
    
    <view class="login-form">
      <view class="role-selector">
        <button 
          :class="['role-btn', activeRole == 'student' ? 'active' : '']"
          @click="activeRole = 'student'"
        >学生登录</button>
        <button 
          :class="['role-btn', activeRole == 'teacher' ? 'active' : '']"
          @click="activeRole = 'teacher'"
        >教师登录</button>
      </view>
      
      <view class="input-group">
        <input 
          v-model="username" 
          :placeholder="activeRole == 'student' ? '请输入学号' : '请输入教师号'"
          class="input"
        />
        <input 
          v-model="password" 
          type="password" 
          placeholder="请输入密码"
          class="input"
        />
      </view>
      
      <button class="login-btn" @click="handleLogin">登录</button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      activeRole: 'student',
      username: '',
      password: ''
    }
  },
  methods: {
    async handleLogin() {
  if (!this.username || !this.password) {
    uni.showToast({
      title: '请输入账号和密码',
      icon: 'none'
    });
    return;
  }
  
  try {
    const response = await getApp().call({
      path: `/api/${this.activeRole}/login`,
      method: 'POST',
      data: {
        [this.activeRole === 'student' ? 'sno' : 'tno']: this.username,
        [this.activeRole === 'student' ? 'spwd' : 'tpwd']: this.password
      }
    });
    
    console.log('登录响应:', response); // 添加日志，方便调试
    
    if (response.success) {
      // 保存用户信息
      uni.setStorageSync('userInfo', response.data);
      uni.setStorageSync('role', this.activeRole);
      
      // 跳转到对应页面
      if (this.activeRole == 'student') {
        uni.reLaunch({
          url: '/pages/student/index'
        });
      } else {
        uni.navigateTo({
          url: '/pages/teacher/index'
        });
      }
    } else {
      uni.showToast({
        title: response.message || '登录失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('登录失败:', error); // 添加错误日志
    uni.showToast({
      title: '登录失败，请稍后重试',
      icon: 'none'
    });
  }
}
  }
}
</script>

<style>
.login-container {
  padding: 40rpx;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f5f5f5;
}

.login-header {
  margin-bottom: 60rpx;
  text-align: center;
}

.title {
  font-size: 48rpx;
  font-weight: bold;
  color: #333;
}

.login-form {
  background-color: #fff;
  padding: 40rpx;
  border-radius: 20rpx;
  box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.1);
}

.role-selector {
  display: flex;
  justify-content: space-around;
  margin-bottom: 40rpx;
}

.role-btn {
  width: 45%;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  border-radius: 40rpx;
  background-color: #f0f0f0;
  color: #666;
  font-size: 32rpx;
}

.role-btn.active {
  background-color: #007AFF;
  color: #fff;
}

.input-group {
  margin-bottom: 40rpx;
}

.input {
  height: 88rpx;
  border: 2rpx solid #eee;
  border-radius: 44rpx;
  padding: 0 30rpx;
  margin-bottom: 20rpx;
  font-size: 32rpx;
}

.login-btn {
  height: 88rpx;
  line-height: 88rpx;
  background-color: #007AFF;
  color: #fff;
  border-radius: 44rpx;
  font-size: 32rpx;
}
</style> 