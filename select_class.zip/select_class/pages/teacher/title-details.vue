<template>
  <view class="container">
    <!-- 课题详情 -->
    <view class="title-details">
      <view class="title-header">
        <text class="title-name">{{titleInfo.titlename}}</text>
        <text class="title-type">{{titleInfo.type === '教师设置' ? '教师设置' : titleInfo.type === '学生申请' ? '学生申请' : '已通过申请'}}</text>
      </view>
      
      <view class="info-section">
        <view class="info-item">
          <text class="label">最大人数：</text>
          <text class="value">{{titleInfo.maxCount}}</text>
        </view>
        <view class="info-item">
          <text class="label">已选人数：</text>
          <text class="value">{{titleInfo.selectedCount}}</text>
        </view>
      </view>
      
      <!-- 学生提交内容 -->
      <view class="submissions-section">
        <view class="section-title">学生提交列表</view>
        <view v-if="submissions.length === 0" class="empty-tip">暂无学生提交</view>
        <view v-else>
          <view class="submission-item" v-for="submission in submissions" :key="submission.sno">
            <view class="submission-header">
              <text class="student-name">{{submission.sname}}</text>
              <text class="student-id">({{submission.sno}})</text>
              <text class="score" v-if="submission.getscore !== null">分数：{{submission.getscore}}</text>
            </view>
            <view class="submission-content">
              <!-- 作品链接 -->
              <view v-if="submission.link_url" class="submission-link">
                <text>作品链接：</text>
                <a :href="submission.link_url" target="_blank">{{submission.link_url}}</a>
              </view>
              <!-- 文件列表 -->
              <view v-if="submission.files && submission.files.length" class="submission-files">
                <text>项目文件：</text>
                <view class="file-list">
                  <view class="file-item" v-for="file in submission.files" :key="file.file_id">
                    <text>{{file.file_name}}</text>
                    <button size="mini" @click="downloadFile(file)">下载</button>
                  </view>
                </view>
              </view>
              <!-- 视频文件 -->
              <view v-if="submission.video_url" class="submission-video">
                <text>视频：</text>
                <button size="mini" @click="downloadVideo(submission)">查看/下载</button>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      titleInfo: {},
      submissions: []
    }
  },
  onLoad(options) {
    this.tno = options.tno || (uni.getStorageSync('userInfo') && uni.getStorageSync('userInfo').tno);
    this.titlename = options.titlename;
    this.loadTitleDetails();
    this.loadSubmissions();
  },
  methods: {
    async loadTitleDetails() {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.tno}/title/${this.titlename}`,
      method: 'GET'
    });
    if (response.success) {
      this.titleInfo = response.data;
    }
  } catch (error) {
    console.error('Error loading title details:', error);
    uni.showToast({
      title: '加载课题详情失败',
      icon: 'none'
    });
  }
},
async loadSubmissions() {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.tno}/title/${this.titlename}/submissions`,
      method: 'GET'
    });
    if (response.success) {
      this.submissions = response.data;
    }
  } catch (error) {
    console.error('Error loading submissions:', error);
    uni.showToast({
      title: '加载提交列表失败',
      icon: 'none'
    });
  }
},
downloadFile(file) {
  getApp().call({
    path: `/api/student/file/${file.file_id}/download`,
    method: 'GET',
    success: (res) => {
      if (res.success) {
        uni.openDocument({
          filePath: res.data.tempFilePath,
          showMenu: true
        });
      } else {
        uni.showToast({ title: '下载失败', icon: 'none' });
      }
    },
    fail: () => {
      uni.showToast({ title: '下载失败', icon: 'none' });
    }
  });
},
downloadVideo(submission) {
  getApp().call({
    path: `/api/teacher/${this.tno}/title/${this.titlename}/student/${submission.sno}/video`,
    method: 'GET',
    success: (res) => {
      if (res.success) {
        uni.openDocument({
          filePath: res.data.tempFilePath,
          showMenu: true
        });
      } else {
        uni.showToast({ title: '下载失败', icon: 'none' });
      }
    },
    fail: () => {
      uni.showToast({ title: '下载失败', icon: 'none' });
    }
  });
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.title-details {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.title-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
}

.title-name {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
}

.title-type {
  font-size: 28rpx;
  color: #666;
}

.info-section {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
  margin-bottom: 30rpx;
}

.info-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.label {
  font-size: 28rpx;
  color: #666;
}

.value {
  font-size: 28rpx;
  color: #333;
}

.submissions-section { background: #fff; border-radius: 20rpx; padding: 30rpx; margin-top: 30rpx; }
.section-title { font-size: 32rpx; font-weight: bold; margin-bottom: 20rpx; }
.submission-item { border-bottom: 2rpx solid #eee; padding: 20rpx 0; }
.submission-header { display: flex; align-items: center; gap: 20rpx; margin-bottom: 10rpx; }
.student-name { font-size: 28rpx; font-weight: bold; }
.student-id { font-size: 24rpx; color: #666; }
.score { color: #4CD964; font-weight: bold; margin-left: 20rpx; }
.submission-content { margin-left: 20rpx; }
.submission-link { margin-bottom: 8rpx; color: #007AFF; }
.submission-files { margin-bottom: 8rpx; }
.file-list { display: flex; flex-wrap: wrap; gap: 10rpx; }
.file-item { display: flex; align-items: center; gap: 8rpx; }
.submission-video { margin-bottom: 8rpx; color: #007AFF; }
.empty-tip { text-align: center; color: #999; padding: 30rpx; }
</style> 