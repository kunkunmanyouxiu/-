<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-item">
        <text class="label">姓名：</text>
        <text class="value">{{userInfo.tname}}</text>
      </view>
      <view class="info-item">
        <text class="label">教师号：</text>
        <text class="value">{{userInfo.tno}}</text>
      </view>
      <view class="export-btn">
        <button class="action-btn" @click="exportScores" :disabled="students.length === 0">
          导出成绩
        </button>
      </view>
    </view>
    
    <!-- 学生列表 -->
    <view class="student-list">
      <view class="section-title">选择课题的学生列表</view>
      <view v-if="loading" class="loading">
        <text>加载中...</text>
      </view>
      <view v-else-if="students.length === 0" class="empty-tip">
        暂无学生选择课题
      </view>
      <view v-else class="student-item" v-for="(student, index) in students" :key="index">
        <view class="student-info">
          <text class="student-name">{{student.sname}}</text>
          <text class="student-id">{{student.sno}}</text>
        </view>
        <view class="course-info">
          <text class="course-name">课题：{{student.titlename}}</text>
          <text class="score" :class="{'has-score': student.getscore}">
            {{student.getscore ? `已评分：${student.getscore}` : '未评分'}}
          </text>
        </view>
        <view class="score-actions">
          <input 
            v-model="student.tempScore" 
            type="number" 
            class="score-input" 
            placeholder="输入分数"
            :disabled="student.submitting"
          />
          <button 
            class="action-btn" 
            @click="submitScore(student)"
            :disabled="!student.tempScore || student.tempScore < 0 || student.tempScore > 100 || student.submitting"
          >
            {{student.getscore ? '修改' : '提交'}}
          </button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      students: [],
      loading: true
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    if (!this.userInfo || !this.userInfo.tno) {
      uni.showToast({
        title: '请先登录',
        icon: 'none'
      });
      setTimeout(() => {
        uni.reLaunch({
          url: '/pages/login/login'
        });
      }, 1500);
      return;
    }
    this.loadStudents();
  },
  methods: {
    async loadStudents() {
  try {
    this.loading = true;
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/students`,
      method: 'GET'
    });
    
    if (response.success) {
      this.students = response.data.map(student => ({
        ...student,
        tempScore: student.getscore || '',
        submitting: false
      }));
    } else {
      uni.showToast({
        title: response.message || '加载失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error loading students:', error);
    uni.showToast({
      title: '加载失败',
      icon: 'none'
    });
  } finally {
    this.loading = false;
  }
},
async submitScore(student) {
  if (!student.tempScore || student.tempScore < 0 || student.tempScore > 100) {
    uni.showToast({
      title: '请输入0-100之间的分数',
      icon: 'none'
    });
    return;
  }
  
  try {
    student.submitting = true;
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/title/${student.titlename}/grade`,
      method: 'POST',
      data: {
        sno: student.sno,
        score: student.tempScore
      }
    });
    
    if (response.success) {
      uni.showToast({
        title: student.getscore ? '修改成功' : '打分成功',
        icon: 'success'
      });
      this.loadStudents();
    } else {
      uni.showToast({
        title: response.message || '操作失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error submitting score:', error);
    uni.showToast({
      title: '操作失败',
      icon: 'none'
    });
  } finally {
    student.submitting = false;
  }
},

async exportScores() {
  if (this.students.length === 0) {
    uni.showToast({
      title: '暂无学生数据',
      icon: 'none'
    });
    return;
  }

  try {
    uni.showLoading({
      title: '正在导出...'
    });

    if (process.env.VUE_APP_PLATFORM === 'h5') {
      const response = await getApp().call({
        path: `/api/teacher/${this.userInfo.tno}/export-scores`,
        method: 'GET',
        responseType: 'blob'
      });
      
      if (response.success) {
        const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `学生成绩_${this.userInfo.tno}_${Date.now()}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }
    } else {
      const response = await getApp().call({
        path: `/api/teacher/${this.userInfo.tno}/export-scores`,
        method: 'GET',
        responseType: 'blob'
      });
      
      if (response.success) {
        const filePath = `${uni.env.USER_DATA_PATH}/scores_${Date.now()}.xlsx`;
        await uni.saveFile({
          tempFilePath: response.data,
          filePath: filePath
        });
        
        uni.openDocument({
          filePath: filePath,
          fileType: 'xlsx',
          success: () => {
            uni.showToast({
              title: '导出成功',
              icon: 'success'
            });
          },
          fail: () => {
            uni.showToast({
              title: '打开文件失败',
              icon: 'none'
            });
          }
        });
      }
    }
  } catch (error) {
    console.error('Error exporting scores:', error);
    uni.showToast({
      title: '导出失败',
      icon: 'none'
    });
  } finally {
    uni.hideLoading();
  }
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.student-list {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.student-item {
  border-bottom: 2rpx solid #eee;
  padding: 20rpx 0;
}

.student-info {
  margin-bottom: 10rpx;
}

.student-name {
  font-size: 32rpx;
  font-weight: bold;
  margin-right: 20rpx;
}

.student-id {
  font-size: 24rpx;
  color: #666;
}

.course-info {
  margin-bottom: 10rpx;
}

.course-name {
  font-size: 28rpx;
  color: #333;
  margin-right: 20rpx;
}

.score {
  font-size: 24rpx;
  color: #666;
}

.score.has-score {
  color: #4CD964;
  font-weight: bold;
}

.score-actions {
  display: flex;
  align-items: center;
  gap: 20rpx;
}

.score-input {
  width: 200rpx;
  height: 60rpx;
  border: 2rpx solid #eee;
  border-radius: 30rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
}

.score-input:disabled {
  background-color: #f5f5f5;
  color: #999;
}

.action-btn {
  width: 120rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.action-btn:disabled {
  background-color: #ccc;
}

.export-btn {
  margin-top: 20rpx;
  text-align: right;
}

.export-btn .action-btn {
  width: 200rpx;
  background-color: #4CD964;
}

.loading {
  text-align: center;
  padding: 30rpx;
  color: #666;
}

.empty-tip {
  text-align: center;
  padding: 30rpx;
  color: #999;
}
</style> 