<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-item">
        <text class="label">姓名：</text>
        <text class="value">{{studentInfo.sname}}</text>
      </view>
      <view class="info-item">
        <text class="label">学号：</text>
        <text class="value">{{studentInfo.sno}}</text>
      </view>
      <view class="info-item">
        <text class="label">班级：</text>
        <text class="value">{{studentInfo.cname}}</text>
      </view>
    </view>
    
    <!-- 已选课题 -->
    <view class="section">
      <view class="section-title">已选课题</view>
      <view class="course-list">
        <view class="course-item" v-for="(course, index) in studentCourses" :key="index">
          <view class="course-info">
            <text class="course-name">{{course.titlename}}</text>
            <text class="course-teacher">教师：{{course.tname}}</text>
            <text class="course-type">{{course.type === 'teacher' ? '教师设置' : '学生申请'}}</text>
            <text class="course-score" v-if="course.getscore">成绩：{{course.getscore}}</text>
            <text class="course-score" v-else>未评分</text>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 队伍信息 -->
    <view class="section" v-if="teamInfo">
      <view class="section-title">队伍信息</view>
      <view class="team-info">
        <text class="team-name">队伍名称：{{teamInfo.team_name}}</text>
        <text class="team-role">{{teamInfo.leader_sno === studentInfo.sno ? '队长' : '队员'}}</text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      studentInfo: {},
      studentCourses: [],
      teamInfo: null
    }
  },
  onLoad(options) {
    this.loadStudentInfo(options.sno);
  },
  methods: {
    async loadStudentInfo(sno) {
  try {
    const response = await getApp().call({
      path: `/api/student/${sno}`,
      method: 'GET'
    });
    
    if (response.success) {
      this.studentInfo = response.data.student;
      this.studentCourses = response.data.titles;
      this.teamInfo = response.data.team;
    }
  } catch (error) {
    console.error('Error loading student info:', error);
    uni.showToast({
      title: '加载学生信息失败',
      icon: 'none'
    });
  }
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.course-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.course-item {
  border-bottom: 2rpx solid #eee;
  padding: 20rpx 0;
}

.course-info {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}

.course-name {
  font-size: 32rpx;
  font-weight: bold;
}

.course-teacher {
  font-size: 28rpx;
  color: #666;
}

.course-type {
  font-size: 24rpx;
  color: #007AFF;
}

.course-score {
  font-size: 28rpx;
  color: #4CD964;
}

.team-info {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}

.team-name {
  font-size: 32rpx;
  font-weight: bold;
}

.team-role {
  font-size: 28rpx;
  color: #007AFF;
}
</style> 