<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-left">
        <view class="info-item">
          <text class="label">姓名：</text>
          <text class="value">{{userInfo.tname}}</text>
        </view>
        <view class="info-item">
          <text class="label">工号：</text>
          <text class="value">{{userInfo.tno}}</text>
        </view>
      </view>
    </view>
    
    <!-- 选课时间设置 -->
    <view class="section">
      <view class="section-title">选课时间设置</view>
      <view class="time-setting">
        <view class="form-item">
          <text class="label">开始时间：</text>
          <view class="time-picker-group">
            <picker 
              mode="date" 
              :value="startDate" 
              @change="onStartDateChange"
              :start="minDate"
              :end="maxDate"
            >
              <view class="picker">{{startDate || '请选择日期'}}</view>
            </picker>
            <picker 
              mode="time" 
              :value="startTime" 
              @change="onStartTimeChange"
            >
              <view class="picker">{{startTime || '请选择时间'}}</view>
            </picker>
          </view>
        </view>
        <view class="form-item">
          <text class="label">结束时间：</text>
          <view class="time-picker-group">
            <picker 
              mode="date" 
              :value="endDate" 
              @change="onEndDateChange"
              :start="minDate"
              :end="maxDate"
            >
              <view class="picker">{{endDate || '请选择日期'}}</view>
            </picker>
            <picker 
              mode="time" 
              :value="endTime" 
              @change="onEndTimeChange"
            >
              <view class="picker">{{endTime || '请选择时间'}}</view>
            </picker>
          </view>
        </view>
    
        <view class="button-group">
          <button class="save-btn" @click="saveTimeSetting">保存时间设置</button>
          <button class="auto-assign-btn" @click="autoAssignStudents">手动分配未选课学生</button>
        </view>
      </view>
    </view>
    
    <!-- 课题列表 -->
    <view class="section">
      <view class="section-header">
        <text class="section-title">课题列表</text>
        <button class="add-btn" @click="showAddTitleModal">添加课题</button>
      </view>
      <view class="title-list">
        <view class="title-card" v-for="title in titles" :key="title.titlename">
          <view class="title-header">
            <text class="title-name">{{ title.titlename }}</text>
            <text class="title-type" :class="{
              'teacher': title.class_tt === 1,
              'student': title.class_tt === 2,
              'approved': title.class_tt === 3
            }">
              {{ title.type }}
            </text>
          </view>
          <view class="title-info">
            <text class="info-item">最大人数：{{ title.maxCount }}</text>
            <text class="info-item">已选人数：{{ title.selectedCount }}</text>
            <text v-if="title.class_tt === 2" class="info-item">申请人：{{ title.applicant }}</text>
            <text class="info-item">课题来源：{{ 
              title.class_tt === 1 ? '教师设置' : 
              title.class_tt === 2 ? '学生申请' : 
              '已通过申请' 
            }}</text>
          </view>
          <view class="title-actions">
            <button class="action-btn view" @click="viewTitleDetails(title)">查看</button>
            <template v-if="title.class_tt === 2">
              <button class="action-btn approve" @click="approveTitle(title)">同意</button>
              <button class="action-btn reject" @click="rejectTitle(title)">拒绝</button>
            </template>
            <button v-else-if="title.class_tt === 1" class="action-btn delete" @click="deleteTitle(title)">删除</button>
            <button class="action-btn reselect" @click="showReselectRequests(title)">重选申请</button>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 添加课题弹窗 -->
    <view class="modal" v-if="showAddTitle">
      <view class="modal-content">
        <view class="modal-header">
          <text class="modal-title">添加课题</text>
          <text class="modal-close" @click="closeAddTitleModal">×</text>
        </view>
        <view class="modal-body">
          <view class="form-item">
            <text class="label">课题名称：</text>
            <input class="input" v-model="newTitle.titlename" placeholder="请输入课题名称" />
          </view>
          <view class="form-item">
            <text class="label">最大人数：</text>
            <input class="input" type="number" v-model="newTitle.maxCount" placeholder="请输入最大人数" />
          </view>
        </view>
        <view class="modal-footer">
          <button class="btn cancel" @click="closeAddTitleModal">取消</button>
          <button class="btn confirm" @click="addTitle">确定</button>
        </view>
      </view>
    </view>
    <uni-popup ref="reselectPopup" type="dialog">
  <uni-popup-dialog
    type="info"
    title="重选申请列表"
    :before-close="true"
    @close="closeReselectPopup"
  >
    <view class="reselect-list">
      <view v-if="reselectRequests.length === 0" class="empty-tip">
        暂无重选申请
      </view>
      <view v-else v-for="request in reselectRequests" :key="request.id" class="reselect-item">
        <view class="request-info">
          <text class="student-name">学生：{{ request.sname }}</text>
          <text class="request-time">申请时间：{{ formatDate(request.request_time) }}</text>
          <text class="request-reason">申请原因：{{ request.reason }}</text>
        </view>
        <view class="request-actions">
          <button @click="processReselect(request, 'approved')" class="approve-btn">批准</button>
          <button @click="processReselect(request, 'rejected')" class="reject-btn">拒绝</button>
        </view>
      </view>
    </view>
  </uni-popup-dialog>
</uni-popup>
<uni-popup ref="changePasswordPopup" type="dialog">
  <uni-popup-dialog
    type="info"
    title="修改密码"
    :before-close="true"
    @close="closeChangePasswordPopup"
  >
    <view class="password-form">
      <view class="form-item">
        <text class="label">原密码</text>
        <input 
          type="password" 
          v-model="passwordForm.oldPassword" 
          placeholder="请输入原密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">新密码</text>
        <input 
          type="password" 
          v-model="passwordForm.newPassword" 
          placeholder="请输入新密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">确认密码</text>
        <input 
          type="password" 
          v-model="passwordForm.confirmPassword" 
          placeholder="请再次输入新密码"
          class="input"
        />
      </view>
      <button class="submit-btn" @click="submitChangePassword">确认修改</button>
    </view>
  </uni-popup-dialog>
</uni-popup>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      titles: [],
      showAddTitle: false,
      newTitle: {
        titlename: '',
        maxCount: '',
        type: 'teacher'
      },
      timeSetting: {
        startTime: '',
        endTime: ''
      },
      startDate: '',
      startTime: '',
      endDate: '',
      endTime: '',
      minDate: new Date().toISOString().split('T')[0],
      maxDate: new Date(new Date().getFullYear() + 1, 11, 31).toISOString().split('T')[0],
      reselectRequests: [],
      currentTitle: null,
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      }
    }
  },
  onLoad() {
    console.log('页面加载');
    this.userInfo = uni.getStorageSync('userInfo');
    console.log('用户信息:', this.userInfo);
    if (!this.userInfo || !this.userInfo.tno) {
      console.error('未找到用户信息');
      uni.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    this.loadTitles();
    this.getTimeSetting();
  },
  methods: {
    async loadTitles() {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/titles`,
      method: 'GET'
    });
    
    if (response.success) {
      this.titles = response.data;
    }
  } catch (error) {
    console.error('Error loading titles:', error);
    uni.showToast({
      title: '加载课题列表失败',
      icon: 'none'
    });
  }
},
    // 添加时间格式化方法
    formatTime(timeStr) {
      if (!timeStr) return '';
      const date = new Date(timeStr);
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      return `${year}-${month}-${day} ${hours}:${minutes}`;
    },
    
    // 修改获取时间设置方法
    async getTimeSetting() {
      try {
        console.log('开始获取时间设置');
        const res = await getApp().call({
          path: `/api/teacher/${this.userInfo.tno}/time-setting`,
          method: 'GET'
        });
        
        console.log('获取到的响应:', res);
        
        if (res.success && res.data) {
          console.log('解析时间数据:', res.data);
          if (res.data.startTime) {
            const startDateTime = new Date(res.data.startTime);
            console.log('开始时间:', startDateTime);
            // 使用本地日期格式
            this.startDate = `${startDateTime.getFullYear()}-${String(startDateTime.getMonth() + 1).padStart(2, '0')}-${String(startDateTime.getDate()).padStart(2, '0')}`;
            this.startTime = `${String(startDateTime.getHours()).padStart(2, '0')}:${String(startDateTime.getMinutes()).padStart(2, '0')}`;
            console.log('设置后的开始日期和时间:', this.startDate, this.startTime);
          }
          if (res.data.endTime) {
            const endDateTime = new Date(res.data.endTime);
            console.log('结束时间:', endDateTime);
            // 使用本地日期格式
            this.endDate = `${endDateTime.getFullYear()}-${String(endDateTime.getMonth() + 1).padStart(2, '0')}-${String(endDateTime.getDate()).padStart(2, '0')}`;
            this.endTime = `${String(endDateTime.getHours()).padStart(2, '0')}:${String(endDateTime.getMinutes()).padStart(2, '0')}`;
            console.log('设置后的结束日期和时间:', this.endDate, this.endTime);
          }
        } else {
          console.log('没有获取到时间数据，设置默认值');
          // 如果没有数据，设置默认值
          const now = new Date();
          this.startDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
          this.startTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
          
          const endDate = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24小时后
          this.endDate = `${endDate.getFullYear()}-${String(endDate.getMonth() + 1).padStart(2, '0')}-${String(endDate.getDate()).padStart(2, '0')}`;
          this.endTime = `${String(endDate.getHours()).padStart(2, '0')}:${String(endDate.getMinutes()).padStart(2, '0')}`;
          
          // 自动保存默认时间设置
          try {
            const saveRes = await getApp().call({
              path: `/api/teacher/${this.userInfo.tno}/time-setting`,
              method: 'POST',
              data: {
                startTime: `${this.startDate}T${this.startTime}:00`,
                endTime: `${this.endDate}T${this.endTime}:00`
              }
            });
            console.log('保存默认时间设置结果:', saveRes);
          } catch (saveError) {
            console.error('保存默认时间设置失败:', saveError);
          }
        }
      } catch (error) {
        console.error('获取时间设置失败:', error);
        uni.showToast({
          title: '获取时间设置失败',
          icon: 'none'
        });
      }
    },
    
    // 修改保存时间设置方法
    async saveTimeSetting() {
      try {
        if (!this.startDate || !this.startTime || !this.endDate || !this.endTime) {
          uni.showToast({
            title: '请完整设置时间',
            icon: 'none'
          });
          return;
        }
        
        // 构建完整的日期时间字符串，使用本地时间
        const startDateTime = `${this.startDate}T${this.startTime}:00`;
        const endDateTime = `${this.endDate}T${this.endTime}:00`;
        
        const res = await getApp().call({
          path: `/api/teacher/${this.userInfo.tno}/time-setting`,
          method: 'POST',
          data: {
            startTime: startDateTime,
            endTime: endDateTime
          }
        });
        
        if (res.success) {
          uni.showToast({
            title: '保存成功',
            icon: 'success'
          });
        } else {
          throw new Error(res.message || '保存失败');
        }
      } catch (error) {
        console.error('保存时间设置失败:', error);
        uni.showToast({
          title: error.message || '保存失败',
          icon: 'none'
        });
      }
    },
    
    onStartDateChange(e) {
      this.startDate = e.detail.value;
    },
    onStartTimeChange(e) {
      this.startTime = e.detail.value;
    },
    onEndDateChange(e) {
      this.endDate = e.detail.value;
    },
    onEndTimeChange(e) {
      this.endTime = e.detail.value;
    },
    showAddTitleModal() {
      this.newTitle = {
        titlename: '',
        maxCount: '',
        type: 'teacher'
      };
      this.showAddTitle = true;
    },
    closeAddTitleModal() {
      this.showAddTitle = false;
    },
    async addTitle() {
  if (!this.newTitle.titlename || !this.newTitle.maxCount) {
    uni.showToast({
      title: '请填写完整信息',
      icon: 'none'
    });
    return;
  }
  
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/title`,
      method: 'POST',
      data: this.newTitle
    });
    
    if (response.success) {
      uni.showToast({
        title: '添加成功',
        icon: 'success'
      });
      this.closeAddTitleModal();
      this.loadTitles();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error adding title:', error);
    uni.showToast({
      title: '添加失败',
      icon: 'none'
    });
  }
},
    viewTitleDetails(title) {
      uni.navigateTo({
        url: `/pages/teacher/title-details?titlename=${title.titlename}`
      });
    },
    async deleteTitle(title) {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/title/${title.titlename}`,
      method: 'DELETE'
    });
    
    if (response.success) {
      uni.showToast({
        title: '删除成功',
        icon: 'success'
      });
      this.loadTitles();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error deleting title:', error);
    uni.showToast({
      title: '删除失败',
      icon: 'none'
    });
  }
},
async autoAssignStudents() {
  try {
    uni.showLoading({
      title: '正在自动分配...'
    });
    
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/auto-assign`,
      method: 'POST'
    });
    
    uni.hideLoading();
    
    if (response.success) {
      uni.showToast({
        title: response.message,
        icon: 'success'
      });
      // 刷新课题列表
      this.loadTitles();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    uni.hideLoading();
    uni.showToast({
      title: '自动分配失败',
      icon: 'none'
    });
  }
},
async approveTitle(title) {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/title/${title.titlename}/approve`,
      method: 'POST'
    });
    
    if (response.success) {
      uni.showToast({
        title: `已同意申请，已通知${response.data.students.length}名学生`,
        icon: 'success'
      });
      this.loadTitles();
    } else {
      uni.showToast({
        title: response.message || '操作失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error approving title:', error);
    uni.showToast({
      title: '操作失败',
      icon: 'none'
    });
  }
},

async rejectTitle(title) {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/title/${title.titlename}/reject`,
      method: 'POST'
    });
    
    if (response.success) {
      uni.showToast({
        title: `已拒绝申请，已通知${response.data.students.length}名学生`,
        icon: 'success'
      });
      this.loadTitles();
    } else {
      uni.showToast({
        title: response.message || '操作失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error rejecting title:', error);
    uni.showToast({
      title: '操作失败',
      icon: 'none'
    });
  }
},
async showReselectRequests(title) {
  this.currentTitle = title;
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/reselect-requests`,
      method: 'GET'
    });

    if (response.success) {
      this.reselectRequests = response.data;
      this.$refs.reselectPopup.open();
    } else {
      uni.showToast({
        title: response.message || '获取申请列表失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('获取重选申请列表失败:', error);
    uni.showToast({
      title: '获取申请列表失败',
      icon: 'none'
    });
  }
},

// 处理重选申请
async processReselect(request, status) {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/process-reselect`,
      method: 'POST',
      data: {
        requestId: request.id,
        status
      }
    });

    if (response.success) {
      uni.showToast({
        title: '处理成功',
        icon: 'success'
      });
      // 重新加载申请列表
      await this.showReselectRequests(this.currentTitle);
    } else {
      uni.showToast({
        title: response.message || '处理失败',
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('处理重选申请失败:', error);
    uni.showToast({
      title: '处理失败',
      icon: 'none'
    });
  }
},

// 关闭重选申请弹窗
closeReselectPopup() {
  this.currentTitle = null;
  this.reselectRequests = [];
  this.$refs.reselectPopup.close();
},
// 打开修改密码弹窗

  }
}
</script>

<style>
.password-form {
  padding: 20rpx;
}

.password-form .form-item {
  margin-bottom: 20rpx;
}

.password-form .label {
  display: block;
  margin-bottom: 10rpx;
  color: #666;
}

.password-form .input {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 10rpx;
  padding: 0 20rpx;
}

.password-form .submit-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  margin-top: 20rpx;
}

.reselect-list {
  max-height: 600rpx;
  overflow-y: auto;
}

.reselect-item {
  padding: 20rpx;
  border-bottom: 1rpx solid #eee;
}

.request-info {
  margin-bottom: 20rpx;
}

.student-name {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 10rpx;
  display: block;
}

.request-time, .request-reason {
  font-size: 28rpx;
  color: #666;
  margin-bottom: 10rpx;
  display: block;
}

.request-actions {
  display: flex;
  justify-content: flex-end;
  gap: 20rpx;
}

.approve-btn, .reject-btn {
  font-size: 28rpx;
  padding: 10rpx 30rpx;
  border-radius: 30rpx;
}

.approve-btn {
  background: #34C759;
  color: #fff;
}

.reject-btn {
  background: #FF3B30;
  color: #fff;
}

.empty-tip {
  text-align: center;
  color: #999;
  padding: 40rpx 0;
}

.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.info-left {
  display: flex;
  flex-direction: column;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.info-right {
  display: flex;
  align-items: center;
}

.auto-assign-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #FF9500;
  color: #fff;
  border-radius: 40rpx;
  font-size: 32rpx;
}

.auto-assign-btn:active {
  opacity: 0.8;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.time-setting {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.time-picker-group {
  display: flex;
  gap: 20rpx;
}

.picker {
  padding: 20rpx;
  background-color: #fff;
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  color: #333;
  min-width: 200rpx;
  text-align: center;
  font-size: 28rpx;
}

.save-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  font-size: 32rpx;
  margin-top: 20rpx;
}

.title-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.title-card {
  background: #fff;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.title-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.title-name {
  font-size: 18px;
  font-weight: bold;
  color: #333;
}

.title-type {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
}

.title-type.teacher {
  background: #e6f7ff;
  color: #1890ff;
  border: 1px solid #1890ff;
}

.title-type.student {
  background: #f6ffed;
  color: #52c41a;
  border: 1px solid #52c41a;
}

.title-type.approved {
  background: #fff7e6;
  color: #fa8c16;
  border: 1px solid #fa8c16;
}

.title-info {
  margin-bottom: 12px;
  padding: 8px;
  background: #fafafa;
  border-radius: 4px;
}

.info-item {
  display: block;
  color: #666;
  margin-bottom: 4px;
  font-size: 14px;
}

.title-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  flex: 1;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 14px;
  text-align: center;
}

.action-btn.view {
  background: #f0f0f0;
  color: #333;
}

.action-btn.approve {
  background: #52c41a;
  color: #fff;
}

.action-btn.reject {
  background: #ff4d4f;
  color: #fff;
}

.action-btn.delete {
  background: #ff4d4f;
  color: #fff;
}

.action-btn.reselect {
  background: #1890ff;
  color: #fff;
}

.add-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  font-size: 32rpx;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.modal-content {
  width: 600rpx;
  background-color: #fff;
  border-radius: 20rpx;
  overflow: hidden;
}

.modal-header {
  padding: 30rpx;
  border-bottom: 2rpx solid #eee;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
}

.modal-close {
  font-size: 40rpx;
  color: #999;
  padding: 10rpx;
}

.modal-body {
  padding: 30rpx;
}

.form-item {
  display: flex;
  align-items: center;
  margin-bottom: 30rpx;
  padding: 20rpx;
}

.label {
  margin-right: 20rpx;
  color: #666;
  min-width: 120rpx;
  font-size: 28rpx;
}

.form-item .input {
  flex: 1;
  height: 80rpx;
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
}

.form-item .value {
  color: #333;
  font-size: 28rpx;
  margin-left: 20rpx;
}

.modal-footer {
  padding: 30rpx;
  border-top: 2rpx solid #eee;
  display: flex;
  justify-content: flex-end;
  gap: 20rpx;
}

.modal-footer .btn {
  width: 160rpx;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  border-radius: 10rpx;
  font-size: 28rpx;
}

.modal-footer .cancel {
  background-color: #f5f5f5;
  color: #666;
}

.modal-footer .confirm {
  background-color: #007AFF;
  color: #fff;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
  margin-top: 20rpx;
}

.auto-assign-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #FF9500;
  color: #fff;
  border-radius: 40rpx;
  font-size: 32rpx;
}

.auto-assign-btn:active {
  opacity: 0.8;
}

.form-item .value {
  color: #333;
  font-size: 28rpx;
  margin-left: 20rpx;
}
</style> 