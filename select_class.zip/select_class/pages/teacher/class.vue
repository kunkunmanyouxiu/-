<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-item">
        <text class="label">姓名：</text>
        <text class="value">{{userInfo.tname}}</text>
      </view>
      <view class="info-item">
        <text class="label">教师号：</text>
        <text class="value">{{userInfo.tno}}</text>
      </view>
    </view>
    
    <!-- 班级信息 -->
    <view class="section">
      <view class="section-title">班级信息</view>
      <view class="class-info">
        <text class="class-name">班级名称：{{classInfo.cname}}</text>
        <text class="class-id">班级编号：{{classInfo.cno}}</text>
        <text class="student-count">学生人数：{{students.length}}</text>
      </view>
    </view>
    
    <!-- 学生列表 -->
    <view class="section">
      <view class="section-header">
        <text class="section-title">学生列表</text>
        <button class="add-btn" @click="showAddStudentModal">添加学生</button>
      </view>
      <view class="student-list">
        <view class="student-item" v-for="(student, index) in students" :key="index">
          <view class="student-info">
            <text class="student-name">{{student.sname}}</text>
            <text class="student-id">{{student.sno}}</text>
          </view>
          <view class="student-actions">
            <button class="action-btn view" @click="viewStudentDetails(student)">查看</button>
            <button class="action-btn delete" @click="deleteStudent(student)">删除</button>
          </view>
        </view>
      </view>
    </view>
    
    <!-- 添加学生弹窗 -->
    <view class="modal" v-if="showAddStudent">
      <view class="modal-content">
        <view class="modal-header">
          <text class="modal-title">添加学生</text>
          <text class="modal-close" @click="closeAddStudentModal">×</text>
        </view>
        <view class="modal-body">
          <view class="form-item">
            <text class="label">学号：</text>
            <input class="input" v-model="newStudent.sno" placeholder="请输入学号" />
          </view>
          <view class="form-item">
            <text class="label">姓名：</text>
            <input class="input" v-model="newStudent.sname" placeholder="请输入姓名" />
          </view>
          <view class="form-item">
            <text class="label">班级：</text>
            <text class="value">{{classInfo.cname}}</text>
          </view>
        </view>
        <view class="modal-footer">
          <button class="btn cancel" @click="closeAddStudentModal">取消</button>
          <button class="btn confirm" @click="addStudent">确定</button>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      classInfo: {},
      students: [],
      showAddStudent: false,
      newStudent: {
        sno: '',
        sname: '',
        cno: '',
        spwd: ''
      }
    }
  },
  onLoad(options) {
    this.userInfo = uni.getStorageSync('userInfo');
    this.classInfo = {
      cno: options.cno,
      cname: options.cname
    };
    this.loadStudents();
  },
  methods: {
    async loadStudents() {
  try {
    const response = await getApp().call({
      path: `/api/class/${this.classInfo.cno}/students`,
      method: 'GET'
    });
    
    if (response.success) {
      this.students = response.data;
    }
  } catch (error) {
    console.error('Error loading students:', error);
    uni.showToast({
      title: '加载学生列表失败',
      icon: 'none'
    });
  }
},
    viewStudentDetails(student) {
      uni.navigateTo({
        url: `/pages/teacher/student-details?sno=${student.sno}`
      });
    },
    async deleteStudent(student) {
  try {
    const response = await getApp().call({
      path: `/api/class/${this.classInfo.cno}/student/${student.sno}`,
      method: 'DELETE'
    });
    
    if (response.success) {
      uni.showToast({
        title: '删除成功',
        icon: 'success'
      });
      this.loadStudents();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error deleting student:', error);
    uni.showToast({
      title: '删除失败',
      icon: 'none'
    });
  }
},
    showAddStudentModal() {
      this.newStudent = {
        sno: '',
        sname: '',
        cno: this.classInfo.cno,
        spwd: ''
      };
      this.showAddStudent = true;
    },
    closeAddStudentModal() {
      this.showAddStudent = false;
    },
    async addStudent() {
  if (!this.newStudent.sno || !this.newStudent.sname) {
    uni.showToast({
      title: '请填写完整信息',
      icon: 'none'
    });
    return;
  }
  
  try {
    this.newStudent.spwd = this.newStudent.sno;
    
    const response = await getApp().call({
      path: `/api/class/${this.classInfo.cno}/student`,
      method: 'POST',
      data: this.newStudent
    });
    
    if (response.success) {
      uni.showToast({
        title: '添加成功',
        icon: 'success'
      });
      this.closeAddStudentModal();
      this.loadStudents();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error adding student:', error);
    uni.showToast({
      title: '添加失败',
      icon: 'none'
    });
  }
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.class-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.class-name {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 10rpx;
  display: block;
}

.class-id {
  font-size: 24rpx;
  color: #666;
}

.student-count {
  font-size: 24rpx;
  color: #666;
}

.student-list {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.student-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 2rpx solid #eee;
}

.student-info {
  flex: 1;
}

.student-name {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 10rpx;
  display: block;
}

.student-id {
  font-size: 24rpx;
  color: #666;
}

.student-actions {
  display: flex;
  gap: 20rpx;
}

.action-btn {
  width: 120rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.action-btn.delete {
  background-color: #ff3b30;
}

.add-btn {
  width: 100%;
  height: 80rpx;
  line-height: 80rpx;
  background-color: #007AFF;
  color: #fff;
  border-radius: 40rpx;
  font-size: 32rpx;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}

.modal-content {
  width: 600rpx;
  background-color: #fff;
  border-radius: 20rpx;
  overflow: hidden;
}

.modal-header {
  padding: 30rpx;
  border-bottom: 2rpx solid #eee;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
}

.modal-close {
  font-size: 40rpx;
  color: #999;
  padding: 10rpx;
}

.modal-body {
  padding: 30rpx;
}

.form-item {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
}

.form-item .label {
  width: 120rpx;
  color: #666;
}

.form-item .input {
  flex: 1;
  height: 80rpx;
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
}

.form-item .value {
  flex: 1;
  color: #333;
  font-weight: bold;
}

.modal-footer {
  padding: 30rpx;
  border-top: 2rpx solid #eee;
  display: flex;
  justify-content: flex-end;
  gap: 20rpx;
}

.modal-footer .btn {
  width: 160rpx;
  height: 80rpx;
  line-height: 80rpx;
  text-align: center;
  border-radius: 10rpx;
  font-size: 28rpx;
}

.modal-footer .cancel {
  background-color: #f5f5f5;
  color: #666;
}

.modal-footer .confirm {
  background-color: #007AFF;
  color: #fff;
}
</style> 