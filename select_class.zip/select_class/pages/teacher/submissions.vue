<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-item">
        <text class="label">姓名：</text>
        <text class="value">{{userInfo.tname}}</text>
      </view>
      <view class="info-item">
        <text class="label">教师号：</text>
        <text class="value">{{userInfo.tno}}</text>
      </view>
    </view>
    
    <!-- 提交内容列表 -->
    <view class="section">
      <view class="section-title">学生提交内容</view>
      <view class="submissions-list">
        <view class="submission-item" v-for="(submission, index) in submissions" :key="index">
          <view class="submission-header">
            <text class="student-name">{{submission.sname}}</text>
            <text class="student-id">学号：{{submission.sno}}</text>
          </view>
          <view class="submission-content">
            <view class="submission-info">
              <text class="title">课题：{{submission.titlename}}</text>
              <text class="time">提交时间：{{formatTime(submission.submit_time)}}</text>
            </view>
            <view class="submission-files">
              <view class="file-item" v-if="submission.video_url">
                <text class="file-label">视频链接：</text>
                <text class="file-value" @click="openUrl(submission.video_url)">{{submission.video_url}}</text>
              </view>
              <view class="file-item" v-if="submission.video_file">
                <text class="file-label">视频文件：</text>
                <text class="file-value" @click="downloadFile(submission.video_file)">点击下载</text>
              </view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      userInfo: {},
      submissions: []
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    this.loadSubmissions();
  },
  methods: {
    async loadSubmissions() {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/student-submissions`,
      method: 'GET'
    });
    
    if (response.success) {
      this.submissions = response.data;
    }
  } catch (error) {
    console.error('Error loading submissions:', error);
    uni.showToast({
      title: '加载提交内容失败',
      icon: 'none'
    });
  }
},
    formatTime(time) {
      if (!time) return '';
      const date = new Date(time);
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    },
    openUrl(url) {
      if (url) {
        uni.navigateTo({
          url: `/pages/webview/webview?url=${encodeURIComponent(url)}`
        });
      }
    },
    downloadFile(filePath) {
  if (filePath) {
    getApp().call({
      path: filePath,
      method: 'GET',
      responseType: 'blob'
    }).then(response => {
      if (response.success) {
        uni.openDocument({
          filePath: response.data,
          success: function() {
            console.log('打开文档成功');
          }
        });
      }
    }).catch(error => {
      console.error('Error downloading file:', error);
      uni.showToast({
        title: '下载失败',
        icon: 'none'
      });
    });
  }
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.section {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
}

.submissions-list {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.submission-item {
  border: 2rpx solid #eee;
  border-radius: 10rpx;
  padding: 20rpx;
}

.submission-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.student-name {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.student-id {
  font-size: 24rpx;
  color: #666;
}

.submission-content {
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.submission-info {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}

.title {
  font-size: 28rpx;
  color: #333;
}

.time {
  font-size: 24rpx;
  color: #666;
}

.submission-files {
  display: flex;
  flex-direction: column;
  gap: 10rpx;
}

.file-item {
  display: flex;
  align-items: center;
}

.file-label {
  font-size: 28rpx;
  color: #666;
  width: 160rpx;
}

.file-value {
  font-size: 28rpx;
  color: #007AFF;
  flex: 1;
  word-break: break-all;
}
</style> 