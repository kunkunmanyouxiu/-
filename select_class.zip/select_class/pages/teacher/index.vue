<template>
  <view class="container">
    <!-- 顶部用户信息 -->
    <view class="user-info">
      <view class="info-left">
        <view class="info-item">
          <text class="label">姓名：</text>
          <text class="value">{{userInfo.tname}}</text>
        </view>
        <view class="info-item">
          <text class="label">教师号：</text>
          <text class="value">{{userInfo.tno}}</text>
        </view>
      </view>
      <view class="info-right">
        <button class="logout-btn" @click="logout">退出登录</button>
      </view>
    </view>
    
    <!-- 班级列表 -->
    <view class="class-list">
      <view class="section-header">
        <view class="section-title">管理的班级</view>
        <button class="create-btn" @click="showCreateClassModal">创建班级</button>
      </view>
      <view class="class-item" v-for="(classItem, index) in classes" :key="index" @click="viewClass(classItem)">
        <view class="class-info">
          <text class="class-name">{{classItem.cname}}</text>
          <text class="student-count">{{classItem.count}}名学生</text>
        </view>
        <view class="class-actions">
          <button class="action-btn" @click.stop="showImportModal(classItem)">导入学生</button>
        </view>
      </view>
    </view>
    
    <!-- 创建班级弹窗 -->
    <view class="modal" v-if="showCreateClass">
      <view class="modal-content">
        <view class="modal-title">创建班级</view>
        <view class="form-item">
          <text class="label">班级编号</text>
          <input class="input" v-model="newClass.cno" placeholder="请输入班级编号" />
        </view>
        <view class="form-item">
          <text class="label">班级名称</text>
          <input class="input" v-model="newClass.cname" placeholder="请输入班级名称" />
        </view>
        <view class="modal-buttons">
          <button class="cancel-btn" @click="showCreateClass = false">取消</button>
          <button class="confirm-btn" @click="createClass">确定</button>
        </view>
      </view>
    </view>

    <!-- 导入学生弹窗 -->
    <view class="modal" v-if="showImport">
      <view class="modal-content">
        <view class="modal-title">导入学生信息</view>
        <view class="import-tips">
          <text>请上传Excel文件，格式如下：</text>
          <text>学号 | 姓名 | 密码</text>
        </view>
        <view class="file-upload">
          <button class="upload-btn" @click="chooseFile">选择文件</button>
          <text class="file-name" v-if="selectedFile">{{selectedFile.name}}</text>
        </view>
        <view class="modal-buttons">
          <button class="cancel-btn" @click="showImport = false">取消</button>
          <button class="confirm-btn" @click="importStudents">确定</button>
        </view>
      </view>
    </view>
    
    <!-- 底部导航栏 -->
    <view class="tab-bar">
      <view class="tab-item active" @click="switchTab('home')">
        <text class="icon">🏠</text>
        <text class="text">主页</text>
      </view>
      <view class="tab-item" @click="switchTab('title')">
        <text class="icon">📚</text>
        <text class="text">课题</text>
      </view>
      <view class="tab-item" @click="switchTab('score')">
        <text class="icon">📝</text>
        <text class="text">打分</text>
      </view>
      <view class="tab-item" @click="openChangePasswordPopup">
        <text class="icon">🔒</text>
          <text class="text">修改密码</text>
      </view>
    </view>
    <uni-popup ref="changePasswordPopup" type="dialog">
  <uni-popup-dialog
    type="info"
    title="修改密码"
    :before-close="true"
    @close="closeChangePasswordPopup"
  >
    <view class="password-form">
      <view class="form-item">
        <text class="label">原密码</text>
        <input 
          type="password" 
          v-model="passwordForm.oldPassword" 
          placeholder="请输入原密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">新密码</text>
        <input 
          type="password" 
          v-model="passwordForm.newPassword" 
          placeholder="请输入新密码"
          class="input"
        />
      </view>
      <view class="form-item">
        <text class="label">确认密码</text>
        <input 
          type="password" 
          v-model="passwordForm.confirmPassword" 
          placeholder="请再次输入新密码"
          class="input"
        />
      </view>
      <button class="submit-btn" @click="submitChangePassword">确认修改</button>
    </view>
  </uni-popup-dialog>
</uni-popup>
  </view>
</template>

<script>
import { read, utils } from 'xlsx';

export default {
  data() {
    return {
      userInfo: {},
      classes: [],
      showCreateClass: false,
      showImport: false,
      newClass: {
        cno: '',
        cname: ''
      },
      selectedFile: null,
      currentClass: null,
      passwordForm: {
        oldPassword: '',
        newPassword: '',
        confirmPassword: ''
      }
    }
  },
  onLoad() {
    this.userInfo = uni.getStorageSync('userInfo');
    this.loadClasses();
  },
  methods: {
    // 打开修改密码弹窗
openChangePasswordPopup() {
    this.$refs.changePasswordPopup.open();
  },
  
  // 关闭修改密码弹窗
  closeChangePasswordPopup() {
    this.passwordForm = {
      oldPassword: '',
      newPassword: '',
      confirmPassword: ''
    };
    this.$refs.changePasswordPopup.close();
  },
  
  // 提交修改密码
  async submitChangePassword() {
    if (!this.passwordForm.oldPassword || !this.passwordForm.newPassword || !this.passwordForm.confirmPassword) {
      uni.showToast({
        title: '请填写完整信息',
        icon: 'none'
      });
      return;
    }
    
    if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
      uni.showToast({
        title: '两次输入的新密码不一致',
        icon: 'none'
      });
      return;
    }
    
    try {
      const response = await getApp().call({
        path: '/api/teacher/change-password',
        method: 'POST',
        data: {
          tno: this.userInfo.tno,
          oldPassword: this.passwordForm.oldPassword,
          newPassword: this.passwordForm.newPassword
        }
      });
      
      if (response.success) {
        uni.showToast({
          title: '密码修改成功',
          icon: 'success'
        });
        this.closeChangePasswordPopup();
      } else {
        uni.showToast({
          title: response.message || '密码修改失败',
          icon: 'none'
        });
      }
    } catch (error) {
      console.error('修改密码失败:', error);
      uni.showToast({
        title: '密码修改失败',
        icon: 'none'
      });
    }
  },
    async loadClasses() {
  try {
    const response = await getApp().call({
      path: `/api/teacher/${this.userInfo.tno}/classes`,
      method: 'GET'
    });
    
    if (response.success) {
      this.classes = response.data;
      // 获取每个班级的学生数量
      for (let i = 0; i < this.classes.length; i++) {
        const countResponse = await getApp().call({
          path: `/api/class/${this.classes[i].cno}/count`,
          method: 'GET'
        });
        if (countResponse.success) {
          this.classes[i].count = countResponse.data.count;
        }
      }
    }
  } catch (error) {
    console.error('Error loading classes:', error);
    uni.showToast({
      title: '加载班级信息失败',
      icon: 'none'
    });
  }
},
    viewClass(classItem) {
      uni.navigateTo({
        url: `/pages/teacher/class?cno=${classItem.cno}&cname=${classItem.cname}`
      });
    },
    switchTab(tab) {
      switch(tab) {
        case 'title':
          uni.navigateTo({
            url: '/pages/teacher/title'
          });
          break;
        case 'score':
          uni.navigateTo({
            url: '/pages/teacher/score'
          });
          break;
      }
    },
    logout() {
      uni.showModal({
        title: '提示',
        content: '确定要退出登录吗？',
        success: (res) => {
          if (res.confirm) {
            // 清除本地存储的用户信息
            uni.removeStorageSync('userInfo');
            // 跳转到登录页面
            uni.reLaunch({
              url: '/pages/login/login'
            });
          }
        }
      });
    },
    showCreateClassModal() {
      this.showCreateClass = true;
      this.newClass = {
        cno: '',
        cname: ''
      };
    },
    async createClass() {
  if (!this.newClass.cno || !this.newClass.cname) {
    uni.showToast({
      title: '请填写完整信息',
      icon: 'none'
    });
    return;
  }
  
  try {
    console.log(typeof this.newClass.cname);
    console.log(typeof this.userInfo.tno);
    const response = await getApp().call({
      path: '/api/teacher/create-class',
      method: 'POST',
      data: {
        ...this.newClass,
        tno: this.userInfo.tno
      }
    });
    
    if (response.success) {
      uni.showToast({
        title: '创建成功',
        icon: 'success'
      });
      this.showCreateClass = false;
      this.loadClasses();
    } else {
      uni.showToast({
        title: response.message,
        icon: 'none'
      });
    }
  } catch (error) {
    console.error('Error creating class:', error);
    uni.showToast({
      title: '创建失败',
      icon: 'none'
    });
  }
},
    showImportModal(classItem) {
      this.currentClass = classItem;
      this.showImport = true;
      this.selectedFile = null;
    },
    chooseFile() {
      uni.chooseFile({
        count: 1,
        extension: ['.xlsx', '.xls'],
        success: (res) => {
          console.log('选择的文件:', res);
          // 获取文件对象
          const file = res.tempFiles[0];
          this.selectedFile = file;
        },
        fail: (error) => {
          console.error('选择文件失败:', error);
          uni.showToast({
            title: '选择文件失败',
            icon: 'none'
          });
        }
      });
    },
    async importStudents() {
  if (!this.selectedFile) {
    uni.showToast({
      title: '请选择文件',
      icon: 'none'
    });
    return;
  }
  
  try {
    const fileReader = new FileReader();
    const file = this.selectedFile;
    
    return new Promise((resolve, reject) => {
      fileReader.onload = async (e) => {
        try {
          const arrayBuffer = e.target.result;
          const workbook = read(arrayBuffer, { type: 'array' });
          const worksheet = workbook.Sheets[workbook.SheetNames[0]];
          const data = utils.sheet_to_json(worksheet);
          
          const students = data.map(row => {
            if (!row['学号'] || !row['姓名']) {
              throw new Error('Excel文件格式错误：缺少学号或姓名');
            }
            return {
              sno: row['学号'].toString(),
              sname: row['姓名'].toString(),
              spwd: row['密码'] ? row['密码'].toString() : '123456'
            };
          });
          
          const response = await getApp().call({
            path: '/api/teacher/import-students',
            method: 'POST',
            data: {
              cno: this.currentClass.cno,
              students
            }
          });
          
          if (response.success) {
            uni.showToast({
              title: '导入成功',
              icon: 'success'
            });
            this.showImport = false;
            this.loadClasses();
          } else {
            uni.showToast({
              title: response.message || '导入失败',
              icon: 'none'
            });
          }
          resolve();
        } catch (error) {
          console.error('Error importing students:', error);
          uni.showToast({
            title: error.message || '导入失败，请检查文件格式',
            icon: 'none'
          });
          reject(error);
        }
      };
      
      fileReader.onerror = (error) => {
        console.error('Error reading file:', error);
        uni.showToast({
          title: '文件读取失败',
          icon: 'none'
        });
        reject(error);
      };
      
      fileReader.readAsArrayBuffer(file);
    });
  } catch (error) {
    console.error('Error importing students:', error);
    uni.showToast({
      title: error.message || '导入失败，请检查文件格式',
      icon: 'none'
    });
  }
}
  }
}
</script>

<style>
.container {
  padding: 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.user-info {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
}

.info-left {
  flex: 1;
}

.info-right {
  margin-left: 20rpx;
}

.logout-btn {
  width: 160rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #FF3B30;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.info-item {
  display: flex;
  margin-bottom: 20rpx;
}

.label {
  color: #666;
  width: 120rpx;
}

.value {
  color: #333;
  font-weight: bold;
}

.class-list {
  background-color: #fff;
  padding: 30rpx;
  border-radius: 20rpx;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 36rpx;
  font-weight: bold;
}

.create-btn {
  width: 160rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.class-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 2rpx solid #eee;
}

.class-info {
  flex: 1;
}

.class-name {
  font-size: 32rpx;
  font-weight: bold;
}

.student-count {
  font-size: 24rpx;
  color: #666;
}

.class-actions {
  margin-left: 20rpx;
}

.action-btn {
  width: 160rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #007AFF;
  color: #fff;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100rpx;
  background-color: #fff;
  display: flex;
  justify-content: space-around;
  align-items: center;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.tab-item.active {
  color: #007AFF;
}

.icon {
  font-size: 40rpx;
  margin-bottom: 4rpx;
}

.text {
  font-size: 24rpx;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.modal-content {
  width: 600rpx;
  background-color: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
}

.modal-title {
  font-size: 32rpx;
  font-weight: bold;
  margin-bottom: 30rpx;
  text-align: center;
}

.form-item {
  margin-bottom: 20rpx;
}

.import-tips {
  margin-bottom: 20rpx;
  color: #666;
  font-size: 24rpx;
}

.file-upload {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
}

.upload-btn {
  width: 200rpx;
  height: 60rpx;
  line-height: 60rpx;
  text-align: center;
  background-color: #f5f5f5;
  color: #666;
  border-radius: 30rpx;
  font-size: 24rpx;
}

.file-name {
  margin-left: 20rpx;
  color: #666;
  font-size: 24rpx;
}

.modal-buttons {
  display: flex;
  justify-content: space-around;
  margin-top: 30rpx;
}

.cancel-btn, .confirm-btn {
  width: 200rpx;
  height: 70rpx;
  line-height: 70rpx;
  text-align: center;
  border-radius: 35rpx;
  font-size: 28rpx;
}

.cancel-btn {
  background-color: #f5f5f5;
  color: #666;
}

.confirm-btn {
  background-color: #007AFF;
  color: #fff;
}
</style> 