<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
			// 初始化云开发
			wx.cloud.init({
				env: 'prod-6gpgn97pa66d2f30', // 云环境ID
			});
			
			// 初始化云托管调用
			this.initCloudContainer();
			
			// 测试云托管接口调用
			this.testCloudCall();
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			async initCloudContainer() {
				const cloud = new wx.cloud.Cloud({
					resourceAppid: 'wxcbe1d095521b03ce', // 云托管环境所属账号的appid
					resourceEnv: 'prod-6gpgn97pa66d2f30', // 云环境ID
				});
				this.cloud = cloud;
				await this.cloud.init();
			},
			
			/**
			 * 封装的微信云托管调用方法
			 * @param {Object} obj 业务请求信息
			 * @param {number} number 请求等待次数，默认0
			 */
			async call(obj, number = 0) {
				if (!this.cloud) {
					await this.initCloudContainer();
				}
				
				try {
					const result = await this.cloud.callContainer({
						config: {
							env: 'prod-6gpgn97pa66d2f30'
						},
						path: obj.path,
						method: obj.method || 'GET',
						data: obj.data,
						header: {
							'X-WX-SERVICE': 'select-class', // 内网服务地址
							...obj.header
						}
					});
					
					console.log(`微信云托管调用结果${result.errMsg} | callid:${result.callID}`);
					return result.data;
				} catch (e) {
					const error = e.toString();
					// 如果错误信息为未初始化，则等待300ms再次尝试
					if (error.indexOf("Cloud API isn't enabled") != -1 && number < 3) {
						return new Promise((resolve) => {
							setTimeout(() => {
								resolve(this.call(obj, number + 1));
							}, 300);
						});
					} else {
						throw new Error(`微信云托管调用失败${error}`);
					}
				}
			},

			/**
			 * 测试云托管接口调用
			 */
			async testCloudCall() {
				try {
					console.log('开始测试云托管接口调用...');
					
					// 测试获取可选课题列表
					const titleResponse = await this.call({
						path: '/api/title/available',
						method: 'GET'
					});
					console.log('获取可选课题列表结果:', titleResponse);
					
					// 测试获取所有课题
					const allTitlesResponse = await this.call({
						path: '/api/title/all',
						method: 'GET'
					});
					console.log('获取所有课题结果:', allTitlesResponse);
					
					console.log('云托管接口测试完成');
				} catch (error) {
					console.error('云托管接口测试失败:', error);
				}
			}
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
