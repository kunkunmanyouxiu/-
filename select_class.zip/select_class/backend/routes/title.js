const express = require('express');
const router = express.Router();
const db = require('../db');

// 获取所有课题
router.get('/', async (req, res) => {
    try {
        const [titles] = await db.query('SELECT * FROM title_class');
        console.log('所有课题:', titles);
        res.json({ success: true, data: titles });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取学生申请的课题
router.get('/applications', async (req, res) => {
    try {
        const [applications] = await db.query('SELECT * FROM title_class WHERE class_tt = 2');
        res.json({ success: true, data: applications });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取教师设置的课题
router.get('/teacher', async (req, res) => {
    try {
        const [titles] = await db.query('SELECT * FROM title_class WHERE class_tt = 1');
        res.json({ success: true, data: titles });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取已选课题
router.get('/selected', async (req, res) => {
    try {
        const [titles] = await db.query('SELECT * FROM title_class WHERE class_tt = 3');
        res.json({ success: true, data: titles });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取可选课题
router.get('/available', async (req, res) => {
    try {
        // 执行实际查询
        const [titles] = await db.query(`
            SELECT tc.*, t.tname
            FROM title_class tc 
            LEFT JOIN teacher t ON tc.tno = t.tno
            WHERE tc.class_tt = 1
        `);
        console.log('可选课题查询结果:', titles);
        
        if (titles.length === 0) {
            return res.json({ success: false, message: '没有可选课题' });
        }
        
        res.json({ success: true, data: titles });
    } catch (error) {
        console.error('获取可选课题失败:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取课题详情
router.get('/:titlename', async (req, res) => {
    try {
        const { titlename } = req.params;
        const [title] = await db.query('SELECT * FROM title_class WHERE titlename = ?', [titlename]);
        if (title.length > 0) {
            res.json({ success: true, data: title[0] });
        } else {
            res.json({ success: false, message: '课题不存在' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 修改课题状态
router.put('/:titlename/status', async (req, res) => {
    try {
        const { titlename } = req.params;
        const { status } = req.body;
        await db.query('UPDATE title_class SET class_tt = ? WHERE titlename = ?', [status, titlename]);
        res.json({ success: true, message: '状态更新成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router; 