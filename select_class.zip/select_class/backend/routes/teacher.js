const express = require('express');
const router = express.Router();
const db = require('../db');
const XLSX = require('xlsx');
const cron = require('node-cron');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 教师登录
router.post('/login', async (req, res) => {
    try {
        const { tno, tpwd } = req.body;
        const [rows] = await db.query('SELECT * FROM teacher WHERE tno = ? AND tpwd = ?', [tno, tpwd]);
        if (rows.length > 0) {
            res.json({ success: true, data: rows[0] });
        } else {
            res.json({ success: false, message: '教师号或密码错误' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

router.post('/:tno/title/:titlename/approve', async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        
        // 检查课题是否存在且为"学生申请"
        const [title] = await db.query(
            'SELECT * FROM title_class WHERE tno = ? AND titlename = ? AND class_tt = 2',
            [tno, titlename]
        );
        
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在或状态不正确' });
        }
        
        // 更新课题状态为"已通过申请"
        await db.query(
            'UPDATE title_class SET class_tt = 3, select_no = 1 WHERE tno = ? AND titlename = ?',
            [tno, titlename]
        );
        
        // 更新所有选择该课题的学生的状态为"已通过"
        await db.query(
            'UPDATE title_select SET status = "approved" WHERE titlename = ?',
            [titlename]
        );
        
        // 获取所有选择该课题的学生信息
        const [students] = await db.query(
            'SELECT s.sno, s.sname FROM student s JOIN title_select ts ON s.sno = ts.sno WHERE ts.titlename = ?',
            [titlename]
        );
        
        // 添加通知记录
        for (const student of students) {
            await db.query(
                'INSERT INTO notification (sno, type, titlename, message) VALUES (?, ?, ?, ?)',
                [
                    student.sno,
                    'approve',
                    titlename,
                    `您的课题申请"${titlename}"已通过`
                ]
            );
        }
        
        res.json({ 
            success: true, 
            message: '已同意申请',
            data: {
                students: students
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 拒绝课题申请
router.post('/:tno/title/:titlename/reject', async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        
        // 检查课题是否存在且为"学生申请"
        const [title] = await db.query(
            'SELECT * FROM title_class WHERE tno = ? AND titlename = ? AND class_tt = 2',
            [tno, titlename]
        );
        
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在或状态不正确' });
        }
        
        // 获取所有选择该课题的学生信息
        const [students] = await db.query(
            'SELECT s.sno, s.sname FROM student s JOIN title_select ts ON s.sno = ts.sno WHERE ts.titlename = ?',
            [titlename]
        );
        
        // 更新所有选择该课题的学生的状态为"已拒绝"
        await db.query(
            'UPDATE title_select SET status = "rejected" WHERE titlename = ?',
            [titlename]
        );
        
        // 添加通知记录
        for (const student of students) {
            await db.query(
                'INSERT INTO notification (sno, type, titlename, message) VALUES (?, ?, ?, ?)',
                [
                    student.sno,
                    'reject',
                    titlename,
                    `您的课题申请"${titlename}"已被拒绝`
                ]
            );
        }
        
        // 删除课题
        await db.query(
            'DELETE FROM title_class WHERE tno = ? AND titlename = ? AND class_tt = 2',
            [tno, titlename]
        );
        
        res.json({ 
            success: true, 
            message: '已拒绝申请',
            data: {
                students: students
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取教师管理的班级
router.get('/:tno/classes', async (req, res) => {
    try {
        const { tno } = req.params;
        const [classes] = await db.query(`
            SELECT c.cno, c.cname 
            FROM class c 
            JOIN teacher_class tc ON c.cno = tc.cno 
            WHERE tc.tno = ?
        `, [tno]);
        res.json({ success: true, data: classes });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});


//创建班级
router.post('/create-class', async (req, res) => {
    try {
        // 从请求体中获取课程名称和教师编号
        const { tno, cname, cno } = req.body;
        console.log('已经获取信息');
        // 检查请求体中是否包含必要的数据
        if (!cname || !cno) {
            return res.status(400).json({ error: 'Missing cname or tno in request body' });
        }
        console.log(typeof cno);
        console.log(typeof cname);
        // 插入课程数据到数据库
        const [result] = await db.execute('INSERT INTO class (cno, cname) VALUES (?, ?)', [cno, cname]);
        await db.query('INSERT INTO teacher_class (tno, cno) VALUES (?, ?)', [tno, cno]);
        // 返回成功响应
        res.status(201).json({ message: 'Class created successfully', classId: result.insertId, success:true });
    } catch (error) {
        console.error('Error creating class:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// 添加教师管理班级
router.post('/:tno/classes/:cno', async (req, res) => {
    try {
        const { tno, cno } = req.params;
        await db.query('INSERT INTO teacher_class (tno, cno) VALUES (?, ?)', [tno, cno]);
        res.json({ success: true, message: '添加成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 移除教师管理的班级
router.delete('/:tno/classes/:cno', async (req, res) => {
    try {
        const { tno, cno } = req.params;
        await db.query('DELETE FROM teacher_class WHERE tno = ? AND cno = ?', [tno, cno]);
        res.json({ success: true, message: '移除成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取班级学生列表
router.get('/class/:cno/students', async (req, res) => {
    try {
        const { cno } = req.params;
        const { tno } = req.query; // 添加教师号参数
        
        // 检查教师是否有权限访问该班级
        const [hasAccess] = await db.query('SELECT * FROM teacher_class WHERE tno = ? AND cno = ?', [tno, cno]);
        if (hasAccess.length === 0) {
            return res.json({ success: false, message: '您没有权限访问该班级' });
        }
        
        const [students] = await db.query('SELECT * FROM student WHERE cno = ?', [cno]);
        res.json({ success: true, data: students });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取教师信息
router.get('/:tno', async (req, res) => {
    try {
        const { tno } = req.params;
        const [teacher] = await db.query('SELECT * FROM teacher WHERE tno = ?', [tno]);
        
        if (teacher.length === 0) {
            return res.status(404).json({ success: false, message: '教师不存在' });
        }
        
        res.json({ success: true, data: teacher[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取教师设置的课题
router.get('/:tno/titles', async (req, res) => {
    try {
        const { tno } = req.params;
        
        // 获取教师设置的课题和学生申请的课题
        const [titles] = await db.query(`
            SELECT 
                tc.titlename,
                tc.select_no as maxCount,
                tc.class_tt,
                CASE 
                    WHEN tc.class_tt = 1 THEN '教师设置'
                    WHEN tc.class_tt = 2 THEN '学生申请'
                    WHEN tc.class_tt = 3 THEN '已通过申请'
                END as type,
                COALESCE(COUNT(ts.sno), 0) as selectedCount,
                tc.tno,
                CASE 
                    WHEN tc.class_tt = 2 THEN (
                        SELECT s.sname 
                        FROM student s 
                        JOIN title_select ts ON s.sno = ts.sno 
                        WHERE ts.titlename = tc.titlename 
                        LIMIT 1
                    )
                    ELSE NULL
                END as applicant
            FROM title_class tc
            LEFT JOIN title_select ts ON tc.titlename = ts.titlename AND ts.status = 'approved'
            WHERE tc.tno = ? OR tc.titlename IN (
                SELECT ts.titlename 
                FROM title_select ts 
                JOIN student s ON ts.sno = s.sno 
                WHERE s.cno IN (
                    SELECT cno FROM teacher_class WHERE tno = ?
                )
            )
            GROUP BY tc.titlename, tc.select_no, tc.class_tt, tc.tno
            ORDER BY tc.class_tt, tc.titlename
        `, [tno, tno]);
        
        res.json({ success: true, data: titles });
    } catch (error) {
        console.error('Error in /:tno/titles:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取课题详情
router.get('/:tno/title/:titlename', async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        
        // 获取课题详情
        const [title] = await db.query(
            'SELECT tc.titlename, tc.select_no as maxCount, ' +
            'CASE WHEN tc.class_tt = 1 THEN "教师设置" ' +
            'WHEN tc.class_tt = 2 THEN "学生申请" ' +
            'WHEN tc.class_tt = 3 THEN "已通过申请" END as type, ' +
            'COALESCE(COUNT(ts.sno), 0) as selectedCount ' +
            'FROM title_class tc ' +
            'LEFT JOIN title_select ts ON tc.titlename = ts.titlename AND ts.status = "approved" ' +
            'WHERE tc.tno = ? AND tc.titlename = ? ' +
            'GROUP BY tc.titlename, tc.select_no, tc.class_tt',
            [tno, titlename]
        );
        
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在' });
        }
        
        res.json({ success: true, data: title[0] });
    } catch (error) {
        console.error('Error in /:tno/title/:titlename:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 配置文件上传
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, '../uploads/videos');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 100 * 1024 * 1024 // 限制文件大小为100MB
    },
    fileFilter: function (req, file, cb) {
        // 只接受视频文件
        if (!file.originalname.match(/\.(mp4|avi|mov|wmv|flv|mkv)$/)) {
            return cb(new Error('只允许上传视频文件！'), false);
        }
        cb(null, true);
    }
});

// 下载学生视频
router.get('/:tno/title/:titlename/student/:sno/video', async (req, res) => {
    try {
        const { tno, titlename, sno } = req.params;
        
        // 检查课题是否存在
        const [title] = await db.query('SELECT * FROM title_class WHERE tno = ? AND titlename = ?', [tno, titlename]);
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在' });
        }
        
        // 获取学生视频信息
        const [submission] = await db.query(
            'SELECT video_file, video_url FROM title_select WHERE sno = ? AND titlename = ?',
            [sno, titlename]
        );
        
        if (!submission || !submission[0] || !submission[0].video_file) {
            return res.status(404).json({ success: false, message: '未找到视频文件' });
        }
        
        const videoPath = path.join(__dirname, '../uploads/videos', submission[0].video_file);
        
        if (!fs.existsSync(videoPath)) {
            return res.status(404).json({ success: false, message: '视频文件不存在' });
        }
        
        // 设置响应头
        res.setHeader('Content-Type', 'video/mp4');
        res.setHeader('Content-Disposition', `attachment; filename=${encodeURIComponent(submission[0].video_file)}`);
        
        // 发送文件
        res.sendFile(videoPath);
    } catch (error) {
        console.error('Error downloading video:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 处理视频上传
router.post('/:tno/title/:titlename/submit-video', upload.single('video'), async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        const { sno } = req.body;

        if (!req.file) {
            return res.status(400).json({ success: false, message: '请选择要上传的视频文件' });
        }

        // 检查课题是否存在
        const [title] = await db.query('SELECT * FROM title_class WHERE tno = ? AND titlename = ?', [tno, titlename]);
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在' });
        }

        // 检查学生是否选择了该课题
        const [selection] = await db.query(
            'SELECT * FROM title_select WHERE sno = ? AND titlename = ?',
            [sno, titlename]
        );

        if (selection.length === 0) {
            return res.status(404).json({ success: false, message: '学生未选择该课题' });
        }

        // 更新视频信息
        const videoUrl = `/uploads/videos/${req.file.filename}`;
        await db.query(
            'UPDATE title_select SET video_url = ?, video_file = ?, submit_time = NOW() WHERE sno = ? AND titlename = ?',
            [videoUrl, req.file.filename, sno, titlename]
        );

        res.json({ 
            success: true, 
            message: '视频上传成功',
            data: {
                video_url: videoUrl,
                video_file: req.file.filename,
                submit_time: new Date()
            }
        });
    } catch (error) {
        console.error('Error in video upload:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取特定课题下的学生提交内容
router.get('/:tno/title/:titlename/submissions', async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        // 检查课题是否存在
        const [title] = await db.query('SELECT * FROM title_class WHERE tno = ? AND titlename = ?', [tno, titlename]);
        if (title.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在' });
        }
        // 获取学生提交内容
        const [submissions] = await db.query(
            'SELECT s.sno, s.sname, ts.status, ts.getscore, ts.video_url, ts.video_file, ts.submit_time, ts.link_url ' +
            'FROM title_select ts ' +
            'JOIN student s ON ts.sno = s.sno ' +
            'WHERE ts.titlename = ? AND ts.status = "approved" ' +
            'ORDER BY ts.submit_time DESC',
            [titlename]
        );
        // 查询每个学生的文件列表
        for (const submission of submissions) {
            const [files] = await db.query(
                'SELECT file_id, file_name, file_type, file_size, upload_time FROM file_storage WHERE sno = ? AND titlename = ?',
                [submission.sno, titlename]
            );
            submission.files = files;
        }
        res.json({ success: true, data: submissions });
    } catch (error) {
        console.error('Error in /:tno/title/:titlename/submissions:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 添加课题
router.post('/:tno/title', async (req, res) => {
    try {
        const { tno } = req.params;
        const { titlename, maxCount } = req.body;
        
        // 检查课题是否已存在
        const [existing] = await db.query('SELECT * FROM title_class WHERE titlename = ?', [titlename]);
        if (existing.length > 0) {
            return res.status(400).json({ success: false, message: '课题已存在' });
        }
        
        // 添加课题，使用select_no字段存储最大人数，class_tt为1表示教师设置的课题
        await db.query('INSERT INTO title_class (titlename, tno, select_no, class_tt) VALUES (?, ?, ?, 1)', 
            [titlename, tno, maxCount]);
        
        res.json({ success: true, message: '添加成功' });
    } catch (error) {
        console.error('Error in /:tno/title:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 删除课题
router.delete('/:tno/title/:titlename', async (req, res) => {
    try {
        const { tno, titlename } = req.params;
        
        // 检查课题是否存在
        const [existing] = await db.query('SELECT * FROM title_class WHERE titlename = ? AND tno = ?', 
            [titlename, tno]);
        if (existing.length === 0) {
            return res.status(404).json({ success: false, message: '课题不存在' });
        }
        
        // 删除课题
        await db.query('DELETE FROM title_class WHERE titlename = ? AND tno = ?', 
            [titlename, tno]);
        
        res.json({ success: true, message: '删除成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取选课时间设置
router.get('/:tno/time-setting', async (req, res) => {
    try {
        const { tno } = req.params;
        
        // 获取选课时间设置
        const [setting] = await db.query('SELECT * FROM course_time WHERE tno = ?', [tno]);
        
        if (setting.length === 0) {
            return res.json({ success: true, data: { startTime: '', endTime: '' } });
        }
        
        // 格式化时间，精确到分钟
        const formattedSetting = {
            startTime: setting[0].startTime ? new Date(setting[0].startTime).toISOString().slice(0, 16) : '',
            endTime: setting[0].endTime ? new Date(setting[0].endTime).toISOString().slice(0, 16) : ''
        };
        
        res.json({ success: true, data: formattedSetting });
    } catch (error) {
        console.error('Error in /:tno/time-setting:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 保存选课时间设置
router.post('/:tno/time-setting', async (req, res) => {
    try {
        const { tno } = req.params;
        let { startTime, endTime } = req.body;
        
        // 检查时间设置是否已存在
        const [existing] = await db.query('SELECT * FROM course_time WHERE tno = ?', [tno]);
        
        if (existing.length === 0) {
            // 添加时间设置
            await db.query('INSERT INTO course_time (tno, startTime, endTime) VALUES (?, ?, ?)', 
                [tno, startTime, endTime]);
        } else {
            // 更新时间设置
            await db.query('UPDATE course_time SET startTime = ?, endTime = ? WHERE tno = ?', 
                [startTime, endTime, tno]);
        }
        
        res.json({ success: true, message: '保存成功' });
    } catch (error) {
        console.error('Error in /:tno/time-setting:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 自动分配未选课学生
async function autoAssignStudents(tno) {
    try {
        console.log(`[${new Date().toLocaleString()}] 开始自动分配学生，教师号: ${tno}`);
        
        // 获取选课时间设置
        const [timeSetting] = await db.query('SELECT * FROM course_time WHERE tno = ?', [tno]);
        if (timeSetting.length === 0) {
            console.log(`教师 ${tno} 未设置选课时间`);
            return { success: false, message: '未设置选课时间' };
        }
        
        const { endTime } = timeSetting[0];
        // 使用北京时间
        const now = new Date();
        now.setHours(now.getHours() + 8);
        const end = new Date(endTime);
        
        console.log('时间检查:');
        console.log('当前时间(北京时间):', now.toLocaleString());
        console.log('结束时间:', end.toLocaleString());
        console.log('时间比较结果:', now > end);
        
        // 检查是否超过选课结束时间
        if (now < end) {
            console.log(`教师 ${tno} 的选课时间未结束`);
            return { success: false, message: '选课时间未结束' };
        }
        
        console.log(`教师 ${tno} 的选课时间已结束，开始分配学生`);
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 获取未选课的学生
            const [unselectedStudents] = await db.query(`
                SELECT DISTINCT s.sno, s.sname, s.cno
                FROM student s
                LEFT JOIN title_select ts ON s.sno = ts.sno AND ts.status = 'approved'
                WHERE s.cno IN (SELECT cno FROM teacher_class WHERE tno = ?)
                AND ts.sno IS NULL
            `, [tno]);
            
            console.log(`找到 ${unselectedStudents.length} 名未选课学生`);
            
            if (unselectedStudents.length === 0) {
                await db.query('COMMIT');
                console.log(`教师 ${tno} 没有未选课的学生`);
                return { success: true, message: '没有未选课的学生' };
            }
            
            // 获取可选课题及其已选人数
            const [availableTitles] = await db.query(`
                SELECT 
                    tc.titlename,
                    tc.select_no as maxCount,
                    COUNT(ts.sno) as selectedCount
                FROM title_class tc
                LEFT JOIN title_select ts ON tc.titlename = ts.titlename AND ts.status = 'approved'
                WHERE tc.tno = ? AND tc.class_tt = 1
                GROUP BY tc.titlename, tc.select_no
                HAVING selectedCount < maxCount
            `, [tno]);
            
            console.log(`找到 ${availableTitles.length} 个可选课题`);
            
            if (availableTitles.length === 0) {
                await db.query('COMMIT');
                console.log(`教师 ${tno} 没有可选的课题`);
                return { success: false, message: '没有可选的课题' };
            }
            
            // 按已选人数排序
            availableTitles.sort((a, b) => a.selectedCount - b.selectedCount);
            console.log('课题排序结果:', availableTitles.map(t => ({
                titlename: t.titlename,
                maxCount: t.maxCount,
                selectedCount: t.selectedCount
            })));
            
            let assignedCount = 0;
            
            // 分配课题
            for (const student of unselectedStudents) {
                console.log(`开始为学生 ${student.sno} (${student.sname}) 分配课题`);
                let assigned = false;
                
                for (const title of availableTitles) {
                    // 检查课题是否已满
                    const [currentCount] = await db.query(`
                        SELECT COUNT(*) as count 
                        FROM title_select 
                        WHERE titlename = ? AND status = 'approved'
                    `, [title.titlename]);
                    
                    console.log(`课题 ${title.titlename} 当前已选人数: ${currentCount[0].count}/${title.maxCount}`);
                    
                    if (currentCount[0].count < title.maxCount) {
                        // 检查学生是否已经被分配
                        const [existingAssignment] = await db.query(`
                            SELECT * FROM title_select 
                            WHERE sno = ? AND status = 'approved'
                        `, [student.sno]);
                        
                        if (existingAssignment.length === 0) {
                            // 分配课题
                            await db.query(`
                                INSERT INTO title_select (sno, titlename, status)
                                VALUES (?, ?, 'approved')
                            `, [student.sno, title.titlename]);
                            
                            console.log(`成功为学生 ${student.sno} 分配课题 ${title.titlename}`);
                            assignedCount++;
                            assigned = true;
                            break;
                        } else {
                            console.log(`学生 ${student.sno} 已经被分配了课题`);
                        }
                    } else {
                        console.log(`课题 ${title.titlename} 已满`);
                    }
                }
                
                if (!assigned) {
                    console.log(`无法为学生 ${student.sno} 分配课题，所有课题都已满`);
                }
            }
            
            await db.query('COMMIT');
            console.log(`自动分配完成，成功分配 ${assignedCount} 名学生`);
            return { 
                success: true, 
                message: `成功分配 ${assignedCount} 名学生`,
                data: {
                    assignedCount,
                    totalStudents: unselectedStudents.length
                }
            };
        } catch (error) {
            await db.query('ROLLBACK');
            console.error(`自动分配过程中出错:`, error);
            throw error;
        }
    } catch (error) {
        console.error('自动分配学生失败:', error);
        return { success: false, message: error.message };
    }
}

// 设置定时任务，每分钟检查一次
cron.schedule('* * * * *', async () => {
    try {
        // 获取所有设置了选课时间的教师
        const [teachers] = await db.query(`
            SELECT DISTINCT tno 
            FROM course_time 
            WHERE endTime IS NOT NULL
        `);
        console.log('定时任务执行时间:', new Date().toLocaleString());
        console.log('找到的教师数量:', teachers.length);
        
        // 为每个教师执行自动分配
        for (const teacher of teachers) {
            try {
                const [timeSetting] = await db.query('SELECT * FROM course_time WHERE tno = ?', [teacher.tno]);
                if (timeSetting.length > 0) {
                    const { endTime } = timeSetting[0];
                    // 获取当前时间并添加8小时
                    const now = new Date();
                    now.setHours(now.getHours() + 8);
                    const end = new Date(endTime);
                    
                    console.log(`教师 ${teacher.tno} 的时间检查:`);
                    console.log('当前时间(UTC+8):', now.toLocaleString());
                    console.log('结束时间:', end.toLocaleString());
                    console.log('时间比较结果:', now > end);
                    
                    // 如果选课时间已结束，执行自动分配
                    if (now > end) {
                        console.log(`[${now.toLocaleString()}] 开始为教师 ${teacher.tno} 执行自动分配`);
                        const result = await autoAssignStudents(teacher.tno);
                        console.log(`[${now.toLocaleString()}] 教师 ${teacher.tno} 自动分配结果:`, result);
                    } else {
                        console.log(`教师 ${teacher.tno} 的选课时间还未结束`);
                    }
                }
            } catch (error) {
                console.error(`为教师 ${teacher.tno} 执行自动分配时出错:`, error);
            }
        }
    } catch (error) {
        console.error('定时任务执行失败:', error);
    }
});

// 保留手动触发接口
router.post('/:tno/auto-assign', async (req, res) => {
    try {
        const { tno } = req.params;
        console.log(`[${new Date().toISOString()}] 手动触发自动分配，教师: ${tno}`);
        const result = await autoAssignStudents(tno);
        res.json(result);
    } catch (error) {
        console.error('自动分配学生失败:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 导出学生成绩
router.get('/:tno/export-scores', async (req, res) => {
    try {
        const { tno } = req.params;
        
        // 获取选择老师课题的学生列表
        const [students] = await db.query(`
            SELECT s.sno, s.sname, ts.titlename, ts.getscore
            FROM student s
            JOIN title_select ts ON s.sno = ts.sno
            JOIN title_class tc ON ts.titlename = tc.titlename
            WHERE tc.tno = ? AND ts.status = 'approved'
            ORDER BY ts.titlename, s.sno
        `, [tno]);
        
        // 创建Excel工作簿
        const workbook = XLSX.utils.book_new();
        
        // 按课题分组数据
        const groupedData = {};
        students.forEach(student => {
            if (!groupedData[student.titlename]) {
                groupedData[student.titlename] = [];
            }
            groupedData[student.titlename].push({
                '学号': student.sno,
                '姓名': student.sname,
                '成绩': student.getscore || '未评分'
            });
        });
        
        // 为每个课题创建工作表
        Object.entries(groupedData).forEach(([titlename, data]) => {
            const worksheet = XLSX.utils.json_to_sheet(data);
            XLSX.utils.book_append_sheet(workbook, worksheet, titlename);
        });
        
        // 生成Excel文件
        const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
        
        // 设置响应头
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', 'attachment; filename=student_scores.xlsx');
        res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');
        
        // 发送文件
        res.send(buffer);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取学生提交的内容
router.get('/:tno/student-submissions', async (req, res) => {
    try {
        const { tno } = req.params;
        
        // 获取该教师所有课题下的学生提交内容
        const [submissions] = await db.query(`
            SELECT 
                s.sno,
                s.sname,
                ts.titlename,
                ts.video_url,
                ts.video_file,
                ts.submit_time
            FROM title_select ts
            JOIN student s ON ts.sno = s.sno
            JOIN title_class tc ON ts.titlename = tc.titlename
            WHERE tc.tno = ? AND ts.status = 'approved'
            ORDER BY ts.submit_time DESC
        `, [tno]);
        
        res.json({ success: true, data: submissions });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取选择老师课题的学生列表
router.get('/:tno/students', async (req, res) => {
    const { tno } = req.params;
    
    try {
        // 查询选择该老师课题的学生
        const [students] = await db.query(`
            SELECT 
                s.sno,
                s.sname,
                ts.titlename,
                ts.getscore
            FROM student s
            JOIN title_select ts ON s.sno = ts.sno
            JOIN title_class tc ON ts.titlename = tc.titlename
            WHERE tc.tno = ? AND ts.status = 'approved'
            ORDER BY s.sno
        `, [tno]);

        res.json({
            success: true,
            data: students
        });
    } catch (error) {
        console.error('获取学生列表失败:', error);
        res.status(500).json({
            success: false,
            message: '获取学生列表失败'
        });
    }
});

// 给学生评分
router.post('/:tno/title/:titlename/grade', async (req, res) => {
    const { tno, titlename } = req.params;
    const { sno, score } = req.body;
    
    try {
        // 检查课题是否存在且属于该教师
        const [title] = await db.query('SELECT * FROM title_class WHERE titlename = ? AND tno = ?', [titlename, tno]);
        if (title.length === 0) {
            return res.status(404).json({
                success: false,
                message: '课题不存在或不属于该教师'
            });
        }
        
        // 检查学生是否选择了该课题
        const [selection] = await db.query('SELECT * FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        if (selection.length === 0) {
            return res.status(404).json({
                success: false,
                message: '该学生未选择此课题'
            });
        }
        
        // 更新分数
        await db.query('UPDATE title_select SET getscore = ? WHERE sno = ? AND titlename = ?', [score, sno, titlename]);
        
        res.json({
            success: true,
            message: '评分成功'
        });
    } catch (error) {
        console.error('评分失败:', error);
        res.status(500).json({
            success: false,
            message: '评分失败'
        });
    }
});

router.get('/:tno/reselect-requests', async (req, res) => {
    try {
      const { tno } = req.params;
      
      // 获取该教师所有课题的重选申请
      const [requests] = await db.query(`
        SELECT 
          r.*, 
          s.sname,
          r.titlename
        FROM reselect_request r
        JOIN student s ON r.sno = s.sno
        JOIN title_class tc ON r.titlename = tc.titlename
        WHERE tc.tno = ? AND r.status = 'pending'
        ORDER BY r.request_time DESC
      `, [tno]);
      
      res.json({ success: true, data: requests });
    } catch (error) {
      console.error('获取重选申请列表失败:', error);
      res.status(500).json({ success: false, message: error.message });
    }
});

// 处理重选申请
router.post('/:tno/process-reselect', async (req, res) => {
    try {
      const { tno } = req.params;
      const { requestId, status } = req.body;
      
      // 检查申请是否存在且属于该教师的学生
      const [request] = await db.query(`
        SELECT r.*, s.sno, s.cno
        FROM reselect_request r
        JOIN student s ON r.sno = s.sno
        WHERE r.id = ? AND s.cno IN (
          SELECT cno FROM teacher_class WHERE tno = ?
        )
      `, [requestId, tno]);
      
      if (!request || request.length === 0) {
        return res.status(404).json({ success: false, message: '申请不存在或无权处理' });
      }
      
      // 更新申请状态
      await db.query(
        'UPDATE reselect_request SET status = ?, process_time = NOW() WHERE id = ?',
        [status, requestId]
      );
      
      if (status === 'approved') {
        // 如果批准，更新选题截止时间，给予24小时的选题时间
        const deadline = new Date();
        deadline.setHours(deadline.getHours() + 24);
        
        // 更新该学生所有选题的截止时间
        await db.query(`
          UPDATE title_class tc
          JOIN title_select ts ON tc.titlename = ts.titlename
          SET tc.select_deadline = ?
          WHERE ts.sno = ? AND ts.status = 'approved'
        `, [deadline, request[0].sno]);
      }
      
      res.json({ success: true, message: '处理成功' });
    } catch (error) {
      console.error('处理重选申请失败:', error);
      res.status(500).json({ success: false, message: error.message });
    }
});

// 设置选题截止时间
router.post('/:tno/set-deadline', async (req, res) => {
    try {
      const { titlename, deadline } = req.body;
      
      await db.query(
        'UPDATE title_class SET select_deadline = ? WHERE titlename = ? AND tno = ?',
        [deadline, titlename, req.params.tno]
      );
      
      res.json({ message: '截止时间设置成功' });
    } catch (error) {
      console.error('设置截止时间时出错:', error);
      res.status(500).json({ message: '服务器错误' });
    }
});

router.post('/change-password', async (req, res) => {
    try {
      const { tno, oldPassword, newPassword } = req.body;
      
      // 验证旧密码
      const [teacher] = await db.query(
        'SELECT * FROM teacher WHERE tno = ? AND tpwd = ?',
        [tno, oldPassword]
      );
      
      if (teacher.length === 0) {
        return res.json({
          success: false,
          message: '原密码错误'
        });
      }
      
      // 更新密码
      await db.query(
        'UPDATE teacher SET tpwd = ? WHERE tno = ?',
        [newPassword, tno]
      );
      
      res.json({
        success: true,
        message: '密码修改成功'
      });
    } catch (error) {
      console.error('修改密码失败:', error);
      res.json({
        success: false,
        message: '修改密码失败'
      });
    }
});

//一次性导入学生
router.post('/import-students', async (req,res) => {
    try {
        const { students, cno } = req.body;
        for (let i = 0; i < students.length; i++) {
            const student = students[i];
            await db.query(
                'INSERT INTO student (sno, sname, cno, spwd) VALUES (?, ?, ?, ?) ',
                [student.sno, student.sname, cno, student.spwd]
            );
        }
        res.status(200).json({success: true, message: '学生导入成功' });
    } catch (error) {
        console.log(error);
        res.status(500).json({success: false, message: '导入学生时出现错误' });
    }
    
});

//

module.exports = router; 
