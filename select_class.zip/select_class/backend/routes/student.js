const express = require('express');
const router = express.Router();
const db = require('../db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 配置文件上传
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024 // 限制文件大小为100MB
  }
});

// 统一文件上传逻辑
const fileStorage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, '../uploads/files');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});
const uploadFile = multer({
    storage: fileStorage,
    limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

// 学生登录
router.post('/login', async (req, res) => {
    try {
        const { sno, spwd } = req.body;
        const [rows] = await db.query(`
            SELECT s.*, c.cname 
            FROM student s 
            LEFT JOIN class c ON s.cno = c.cno 
            WHERE s.sno = ? AND s.spwd = ?
        `, [sno, spwd]);
        if (rows.length > 0) {
            res.json({ success: true, data: rows[0] });
        } else {
            res.json({ success: false, message: '学号或密码错误' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取学生信息
router.get('/:sno', async (req, res) => {
    try {
        const { sno } = req.params;
        const [student] = await db.query(`
            SELECT s.*, c.cname 
            FROM student s 
            LEFT JOIN class c ON s.cno = c.cno 
            WHERE s.sno = ?
        `, [sno]);
        const [titles] = await db.query('SELECT * FROM title_select WHERE sno = ?', [sno]);
        const [team] = await db.query('SELECT * FROM stu_team WHERE sno = ?', [sno]);
        
        res.json({
            success: true,
            data: {
                student: student[0],
                titles,
                team: team[0]
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 选择课题
router.post('/select-title', async (req, res) => {
    try {
        const { sno, titlename } = req.body;
        console.log('选课请求参数:', { sno, titlename });
        
        // 检查课题是否存在
        const [title] = await db.query('SELECT * FROM title_class WHERE titlename = ?', [titlename]);
        console.log('课题查询结果:', title);
        if (title.length === 0) {
            return res.json({ success: false, message: '课题不存在' });
        }

        // 检查是否已经选了两个课题
        const [currentTitles] = await db.query('SELECT COUNT(*) as count FROM title_select WHERE sno = ?', [sno]);
        console.log('当前已选课题数量:', currentTitles[0].count);
        if (currentTitles[0].count >= 2) {
            return res.json({ success: false, message: '最多只能选择两个课题' });
        }

        // 检查是否已经选择了该课题
        const [existing] = await db.query('SELECT * FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        console.log('已选课题检查:', existing);
        if (existing.length > 0) {
            return res.json({ success: false, message: '您已经选择了该课题' });
        }

        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 根据课题类型设置不同的状态
            const status = title[0].class_tt === 1 ? 'approved' : 'pending';
            
            // 添加选课记录
            await db.query('INSERT INTO title_select (sno, titlename, status) VALUES (?, ?, ?)',
                [sno, titlename, status]);
            console.log('选课记录添加成功');
            
            // 更新课题选择人数
            await db.query('UPDATE title_class SET select_no = select_no + 1 WHERE titlename = ?', [titlename]);
            console.log('课题选择人数更新成功');
            
            await db.query('COMMIT');
            console.log('事务提交成功');
            
            res.json({ success: true, message: '选课成功' });
        } catch (error) {
            await db.query('ROLLBACK');
            console.error('事务执行失败:', error);
            throw error;
        }
    } catch (error) {
        console.error('选课失败，详细错误:', error);
        res.status(500).json({ 
            success: false, 
            message: '选课失败',
            error: error.message,
            stack: error.stack
        });
    }
});

// 退出课题
router.post('/quit-title', async (req, res) => {
    try {
        const { sno, titlename } = req.body;
        
        await db.query('START TRANSACTION');
        
        // 删除选课记录
        await db.query('DELETE FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        
        // 更新课题选择人数
        await db.query('UPDATE title_class SET select_no = select_no - 1 WHERE titlename = ?', [titlename]);
        
        await db.query('COMMIT');
        
        res.json({ success: true, message: '退课成功' });
    } catch (error) {
        await db.query('ROLLBACK');
        res.status(500).json({ success: false, message: error.message });
    }
});



// 申请课题
router.post('/apply-title', async (req, res) => {
    try {
        const { titlename, tno, sno } = req.body;
        
        // 检查是否已经选择了两个课题
        const [currentTitles] = await db.query('SELECT COUNT(*) as count FROM title_select WHERE sno = ?', [sno]);
        if (currentTitles[0].count >= 2) {
            return res.json({ success: false, message: '您已经选择了两个课题' });
        }
        
        // 检查是否已经申请过该课题
        const [existing] = await db.query('SELECT * FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        if (existing.length > 0) {
            return res.json({ success: false, message: '您已经申请过该课题' });
        }
        
        // 检查是否已经通过队伍选择了课题
        const [teamMember] = await db.query('SELECT * FROM team_member WHERE sno = ?', [sno]);
        if (teamMember.length > 0) {
            const [team] = await db.query('SELECT * FROM team WHERE team_id = ?', [teamMember[0].team_id]);
            if (team.length > 0) {
                const [leaderTitle] = await db.query('SELECT * FROM title_select WHERE sno = ?', [team[0].leader_sno]);
                if (leaderTitle.length > 0) {
                    return res.json({ success: false, message: '您已经通过队伍选择了课题，无法申请新课题' });
                }
            }
        }
        
        // 检查教师是否存在
        const [teacher] = await db.query('SELECT * FROM teacher WHERE tno = ?', [tno]);
        if (teacher.length === 0) {
            return res.json({ success: false, message: '教师不存在' });
        }
        
        // 检查课题是否已存在
        const [title] = await db.query('SELECT * FROM title_class WHERE titlename = ?', [titlename]);
        if (title.length > 0) {
            return res.json({ success: false, message: '该课题已存在' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 添加课题记录
            await db.query('INSERT INTO title_class (titlename, tno, class_tt) VALUES (?, ?, 2)', [titlename, tno]);
            
            // 添加选课记录
            await db.query('INSERT INTO title_select (sno, titlename, status) VALUES (?, ?, "pending")', 
                [sno, titlename]);
            
            await db.query('COMMIT');
            
            res.json({ success: true, message: '申请提交成功' });
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    } catch (error) {
        console.error('申请课题失败:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取学生已选课程
router.get('/:sno/courses', async (req, res) => {
    try {
        const { sno } = req.params;
        const [courses] = await db.query(`
            SELECT 
                ts.*, 
                tc.class_tt, 
                tc.tno,
                tc.select_no,
                t.tname as teacher_name
            FROM title_select ts 
            JOIN title_class tc ON ts.titlename = tc.titlename
            LEFT JOIN teacher t ON tc.tno = t.tno
            WHERE ts.sno = ?
        `, [sno]);
        const [allTitles] = await db.query(`
            SELECT 
                tc.titlename,
                tc.class_tt,
                tc.select_no
            FROM title_class tc
            WHERE tc.class_tt != 1
        `);
        
        console.log('所有需要检查的课题:', allTitles);
        
        // 检查并删除符合条件的课题
        for (const title of allTitles) {
            console.log('检查课题:', {
                titlename: title.titlename,
                class_tt: title.class_tt,
                select_no: title.select_no
            });
            
            if ((title.class_tt === 2 && title.select_no < 0) || 
                (title.class_tt === 3 && title.select_no <= 0)) {
                console.log('符合删除条件，准备删除:', title.titlename);
                
                // 开始事务
                await db.query('START TRANSACTION');
                
                try {
                    // 先删除相关的文件记录
                    await db.query('DELETE FROM file_storage WHERE titlename = ?', [title.titlename]);
                    
                    // 删除选课记录
                    await db.query('DELETE FROM title_select WHERE titlename = ?', [title.titlename]);
                    
                    // 删除课题记录
                    await db.query('DELETE FROM title_class WHERE titlename = ?', [title.titlename]);
                    
                    await db.query('COMMIT');
                    console.log(`已自动删除课题: ${title.titlename}`);
                } catch (error) {
                    await db.query('ROLLBACK');
                    console.error(`删除课题失败: ${title.titlename}`, error);
                    console.error('错误详情:', {
                        class_tt: title.class_tt,
                        select_no: title.select_no,
                        error: error.message
                    });
                }
            }
        }
        
        // 重新获取更新后的课程列表
        const [updatedCourses] = await db.query(`
            SELECT 
                ts.*, 
                tc.class_tt, 
                tc.tno,
                t.tname as teacher_name
            FROM title_select ts 
            JOIN title_class tc ON ts.titlename = tc.titlename
            LEFT JOIN teacher t ON tc.tno = t.tno
            WHERE ts.sno = ?
        `, [sno]);
        
        res.json({ success: true, data: updatedCourses });
    } catch (error) {
        console.error('Error in /:sno/courses:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 申请课程
router.post('/apply', async (req, res) => {
    try {
        const { sno, titlename, reason } = req.body;
        
        // 检查是否已经申请过该课程
        const [existing] = await db.query('SELECT * FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        if (existing.length > 0) {
            return res.json({ success: false, message: '您已经申请过该课程' });
        }
        
        // 检查是否已经申请了两个课程
        const [current] = await db.query('SELECT COUNT(*) as count FROM title_select WHERE sno = ?', [sno]);
        if (current[0].count >= 2) {
            return res.json({ success: false, message: '最多只能申请两个课程' });
        }
        
        await db.query('INSERT INTO title_select (sno, titlename, status) VALUES (?, ?, "pending")', [sno, titlename]);
        res.json({ success: true, message: '申请提交成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 取消课程
router.post('/cancel', async (req, res) => {
    try {
        const { sno, titlename } = req.body;
        
        await db.query('DELETE FROM title_select WHERE sno = ? AND titlename = ?', [sno, titlename]);
        res.json({ success: true, message: '取消成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 上传文件
router.post('/:sno/title/:titlename/upload', upload.single('file'), async (req, res) => {
  try {
    const { sno, titlename } = req.params;
    const file = req.file;
    
    console.log('Received upload request:', { sno, titlename });
    console.log('Uploaded file:', file);
    
    if (!file) {
      console.log('No file received in request');
      return res.status(400).json({ success: false, message: '请选择文件' });
    }

    // 检查文件是否成功保存
    if (!fs.existsSync(file.path)) {
      console.error('File was not saved to disk:', file.path);
      return res.status(500).json({ success: false, message: '文件保存失败' });
    }

    console.log('File saved successfully at:', file.path);

    // 保存文件信息到数据库
    await db.query(
      'INSERT INTO file_storage (sno, titlename, file_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?, ?)',
      [sno, titlename, file.originalname, file.path, file.mimetype, file.size]
    );

    console.log('File information saved to database');

    res.json({ 
      success: true, 
      message: '上传成功',
      data: {
        file_name: file.originalname,
        file_path: file.path,
        file_type: file.mimetype,
        file_size: file.size
      }
    });
  } catch (error) {
    console.error('文件上传失败:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// 获取文件列表
router.get('/:sno/title/:titlename/files', async (req, res) => {
  try {
    const { sno, titlename } = req.params;
    
    const [files] = await db.query(
      'SELECT * FROM file_storage WHERE sno = ? AND titlename = ? ORDER BY upload_time DESC',
      [sno, titlename]
    );

    res.json({ success: true, data: files });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 下载文件
router.get('/file/:file_id/download', async (req, res) => {
    const { file_id } = req.params;
    try {
        const [files] = await db.query('SELECT * FROM file_storage WHERE file_id = ?', [file_id]);
        if (!files[0]) return res.status(404).json({ success: false, message: '文件不存在' });
        // 查找学生姓名
        const [students] = await db.query('SELECT sname FROM student WHERE sno = ?', [files[0].sno]);
        const studentName = students[0] ? students[0].sname : '学生';
        const filePath = path.join(__dirname, '../uploads/files', files[0].file_path);
        if (!fs.existsSync(filePath)) return res.status(404).json({ success: false, message: '文件不存在' });
        // 设置带学生名的文件名
        res.setHeader('Content-Disposition', `attachment; filename=${encodeURIComponent(studentName + '-' + files[0].file_name)}`);
        res.download(filePath);
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 删除文件
router.delete('/file/:file_id', async (req, res) => {
  try {
    const { file_id } = req.params;
    
    const [files] = await db.query(
      'SELECT * FROM file_storage WHERE file_id = ?',
      [file_id]
    );

    if (files.length === 0) {
      return res.status(404).json({ success: false, message: '文件不存在' });
    }

    const file = files[0];
    if (fs.existsSync(file.file_path)) {
      fs.unlinkSync(file.file_path);
    }

    await db.query(
      'DELETE FROM file_storage WHERE file_id = ?',
      [file_id]
    );

    res.json({ success: true, message: '删除成功' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 上传文件（只保留此路由）
router.post('/:sno/title/:titlename/upload-file', uploadFile.single('file'), async (req, res) => {
    const { sno, titlename } = req.params;
    if (!req.file) {
        console.log('未收到文件');
        return res.status(400).json({ success: false, message: '请选择要上传的文件' });
    }
    try {
        // 保存文件信息到 file_storage 表，file_path 只存文件名
        await db.query(
            'INSERT INTO file_storage (sno, titlename, file_name, file_path, file_type, file_size, upload_time) VALUES (?, ?, ?, ?, ?, ?, NOW())',
            [sno, titlename, req.file.originalname, req.file.filename, req.file.mimetype, req.file.size]
        );
        console.log('文件上传成功:', req.file.filename);
        res.json({ success: true, message: '文件上传成功' });
    } catch (error) {
        console.error('文件上传失败:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取文件列表
router.get('/:sno/title/:titlename/files', async (req, res) => {
    const { sno, titlename } = req.params;
    try {
        const [files] = await db.query('SELECT file_id, file_name, file_type, file_size, upload_time FROM file_storage WHERE sno = ? AND titlename = ?', [sno, titlename]);
        res.json({ success: true, data: files });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 上传链接
router.post('/:sno/title/:titlename/submit-link', async (req, res) => {
    const { sno, titlename } = req.params;
    const { link_url } = req.body;
    if (!link_url) return res.status(400).json({ success: false, message: '链接不能为空' });
    try {
        await db.query('UPDATE title_select SET link_url = ? WHERE sno = ? AND titlename = ?', [link_url, sno, titlename]);
        res.json({ success: true, message: '链接提交成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 检查选题时间限制的中间件
const checkTimeLimit = async (req, res, next) => {
    try {
      const { titlename } = req.body;
      const [title] = await db.query(
        'SELECT select_deadline FROM title_class WHERE titlename = ?',
        [titlename]
      );
      
      if (title && title.select_deadline) {
        const now = new Date();
        const deadline = new Date(title.select_deadline);
        
        if (now > deadline) {
          // 检查是否有已批准的重选申请
          const [request] = await db.query(
            'SELECT * FROM reselect_request WHERE sno = ? AND titlename = ? AND status = "approved" ORDER BY request_time DESC LIMIT 1',
            [req.body.sno, titlename]
          );
          
          if (!request) {
            return res.status(403).json({
              message: '选题时间已过，请先申请重新选题权限',
              needReselect: true
            });
          }
        }
      }
      next();
    } catch (error) {
      console.error('检查选题时间限制时出错:', error);
      res.status(500).json({ message: '服务器错误' });
    }
  };
  
  router.post('/change-password', async (req, res) => {
    try {
      const { sno, oldPassword, newPassword } = req.body;
      
      // 验证旧密码
      const [student] = await db.query(
        'SELECT * FROM student WHERE sno = ? AND spwd = ?',
        [sno, oldPassword]
      );
      
      if (student.length === 0) {
        return res.json({
          success: false,
          message: '原密码错误'
        });
      }
      
      // 更新密码
      await db.query(
        'UPDATE student SET spwd = ? WHERE sno = ?',
        [newPassword, sno]
      );
      
      res.json({
        success: true,
        message: '密码修改成功'
      });
    } catch (error) {
      console.error('修改密码失败:', error);
      res.json({
        success: false,
        message: '修改密码失败'
      });
    }
  });

  // 申请重新选题
  router.post('/apply-reselect', async (req, res) => {
    try {
      const { sno, titlename, reason } = req.body;
      
      // 检查是否已有待处理的申请
      const [existing] = await db.query(
        'SELECT * FROM reselect_request WHERE sno = ? AND status = "pending"',
        [sno]
      );
      
      if (existing.length > 0) {
        return res.status(400).json({ success: false, message: '已有待处理的重选申请' });
      }
      
      // 创建新的重选申请
      await db.query(
        'INSERT INTO reselect_request (sno, titlename, reason, request_time, status) VALUES (?, ?, ?, NOW(), "pending")',
        [sno, titlename, reason]
      );
      
      res.json({ success: true, message: '重选申请已提交' });
    } catch (error) {
      console.error('提交重选申请时出错:', error);
      res.status(500).json({ success: false, message: '服务器错误' });
    }
  });
  
  // 获取重选申请状态
  router.get('/reselect-status/:sno/:titlename', async (req, res) => {
    try {
      const { sno, titlename } = req.params;
      const [request] = await db.query(
        'SELECT * FROM reselect_request WHERE sno = ? AND titlename = ? ORDER BY request_time DESC LIMIT 1',
        [sno, titlename]
      );
      
      res.json(request || { status: null });
    } catch (error) {
      console.error('获取重选申请状态时出错:', error);
      res.status(500).json({ message: '服务器错误' });
    }
  });
  
  // 修改选题路由，添加时间限制检查
  router.post('/select-title', checkTimeLimit, async (req, res) => {
    try {
      const { sno, titlename } = req.body;
      
      // 检查是否已经选择了该题目
      const [existing] = await db.query(
        'SELECT * FROM title_select WHERE sno = ? AND titlename = ?',
        [sno, titlename]
      );
      
      if (existing) {
        return res.status(400).json({ message: '已经选择了该题目' });
      }
      
      // 检查当前已选题目数量
      const [currentTitles] = await db.query(
        'SELECT COUNT(*) as count FROM title_select WHERE sno = ?',
        [sno]
      );
      
      if (currentTitles[0].count >= 1) {
        return res.status(400).json({ message: '已经选择了一个题目' });
      }
      
      // 检查题目是否可选
      const [title] = await db.query(
        'SELECT * FROM title_class WHERE titlename = ?',
        [titlename]
      );
      
      if (!title || title.length === 0) {
        return res.status(404).json({ message: '题目不存在' });
      }
      
      // 插入选题记录
      await db.query(
        'INSERT INTO title_select (sno, titlename, status) VALUES (?, ?, "pending")',
        [sno, titlename]
      );
      
      res.json({ message: '选题成功' });
    } catch (error) {
      console.error('选题时出错:', error);
      res.status(500).json({ message: '服务器错误' });
    }
  });
  
// 通过学生学号查找对应的教师号
router.get('/:sno/teacher', async (req, res) => {
  try {
      const { sno } = req.params;
      
      // 先获取学生的班级号
      const [student] = await db.query('SELECT cno FROM student WHERE sno = ?', [sno]);
      
      if (student.length === 0) {
          return res.status(404).json({ success: false, message: '学生不存在' });
      }
      
      const cno = student[0].cno;
      
      // 通过班级号查找对应的教师号
      const [teacher] = await db.query(`
          SELECT t.tno 
          FROM teacher t
          JOIN teacher_class tc ON t.tno = tc.tno
          WHERE tc.cno = ?
          LIMIT 1
      `, [cno]);
      
      if (teacher.length === 0) {
          return res.status(404).json({ success: false, message: '未找到对应的教师' });
      }
      
      res.json({ 
          success: true, 
          data: { tno: teacher[0].tno }
      });
  } catch (error) {
      console.error('查找教师失败:', error);
      res.status(500).json({ success: false, message: error.message });
  }
});

  // 修改退选路由，添加时间限制检查
  router.post('/quit-title', checkTimeLimit, async (req, res) => {
    try {
      const { sno, titlename } = req.body;
      
      // 检查是否选择了该题目
      const [existing] = await db.query(
        'SELECT * FROM title_select WHERE sno = ? AND titlename = ?',
        [sno, titlename]
      );
      
      if (!existing) {
        return res.status(404).json({ message: '未选择该题目' });
      }
      
      // 删除选题记录
      await db.query(
        'DELETE FROM title_select WHERE sno = ? AND titlename = ?',
        [sno, titlename]
      );
      
      res.json({ message: '退选成功' });
    } catch (error) {
      console.error('退选时出错:', error);
      res.status(500).json({ message: '服务器错误' });
    }
  });

// 获取学生通知列表
router.get('/:sno/notifications', async (req, res) => {
  try {
    const { sno } = req.params;
    const [notifications] = await db.query(
      'SELECT * FROM notification WHERE sno = ? ORDER BY create_time DESC',
      [sno]
    );
    res.json({ success: true, data: notifications });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 获取未读通知数量
router.get('/:sno/notifications/unread-count', async (req, res) => {
  try {
    const { sno } = req.params;
    const [result] = await db.query(
      'SELECT COUNT(*) as count FROM notification WHERE sno = ? AND is_read = FALSE',
      [sno]
    );
    res.json({ success: true, data: result[0].count });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 标记通知为已读
router.post('/:sno/notifications/:id/read', async (req, res) => {
  try {
    const { sno, id } = req.params;
    await db.query(
      'UPDATE notification SET is_read = TRUE WHERE id = ? AND sno = ?',
      [id, sno]
    );
    res.json({ success: true, message: '已标记为已读' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 标记所有通知为已读
router.post('/:sno/notifications/read-all', async (req, res) => {
  try {
    const { sno } = req.params;
    await db.query(
      'UPDATE notification SET is_read = TRUE WHERE sno = ?',
      [sno]
    );
    res.json({ success: true, message: '已全部标记为已读' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// 获取选课时间限制
router.get('/course-time-limit', async (req, res) => {
  try {
    // 获取所有教师的选课时间设置
    const [timeSettings] = await db.query(`
      SELECT 
        MIN(startTime) as startTime,
        MAX(endTime) as endTime
      FROM course_time
      WHERE startTime IS NOT NULL AND endTime IS NOT NULL
    `);
    
    if (timeSettings.length === 0 || !timeSettings[0].startTime || !timeSettings[0].endTime) {
      return res.json({ 
        success: true, 
        data: { 
          startTime: null, 
          endTime: null 
        } 
      });
    }
    
    res.json({ 
      success: true, 
      data: {
        startTime: timeSettings[0].startTime,
        endTime: timeSettings[0].endTime
      }
    });
  } catch (error) {
    console.error('获取选课时间限制失败:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// 提交重选申请
router.post('/:sno/reselect-request', async (req, res) => {
    try {
        const { sno } = req.params;
        const { reason, titlename } = req.body;
        
        // 检查学生是否已选择课题
        const [selection] = await db.query(
            'SELECT * FROM title_select WHERE sno = ? AND status = "approved"',
            [sno]
        );
        
        if (selection.length === 0) {
            return res.status(400).json({
                success: false,
                message: '您还没有选择任何课题'
            });
        }
        
        // 创建重选申请
        await db.query(
            'INSERT INTO reselect_request (sno, reason, titlename, status, request_time) VALUES (?, ?, ?, "pending", NOW())',
            [sno, reason, titlename]
        );
        
        res.json({
            success: true,
            message: '重选申请提交成功'
        });
    } catch (error) {
        console.error('提交重选申请失败:', error);
        res.status(500).json({
            success: false,
            message: '提交重选申请失败'
        });
    }
});

module.exports = router; 