const express = require('express');
const router = express.Router();
const db = require('../db');

// 获取班级学生列表
router.get('/:cno/students', async (req, res) => {
    try {
        const { cno } = req.params;
        const [students] = await db.query('SELECT * FROM student WHERE cno = ?', [cno]);
        res.json({ success: true, data: students });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 统计班级学生数量
router.get('/:cno/count', async (req, res) => {
    try {
        const { cno } = req.params;
        const [result] = await db.query('SELECT COUNT(*) as count FROM student WHERE cno = ?', [cno]);
        res.json({ success: true, data: result[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 添加学生
router.post('/:cno/student', async (req, res) => {
    try {
        const { cno } = req.params;
        const { sno, sname, spwd } = req.body;
        
        await db.query('INSERT INTO student (sno, sname, cno, spwd) VALUES (?, ?, ?, ?)', 
            [sno, sname, cno, spwd]);
        
        res.json({ success: true, message: '学生添加成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 删除学生
router.delete('/:cno/student/:sno', async (req, res) => {
    try {
        const { sno } = req.params;
        
        await db.query('START TRANSACTION');
        
        // 删除学生选课记录
        await db.query('DELETE FROM title_select WHERE sno = ?', [sno]);
        
        // 删除学生队伍记录
        await db.query('DELETE FROM stu_team WHERE sno = ?', [sno]);
        
        // 删除学生记录
        await db.query('DELETE FROM student WHERE sno = ?', [sno]);
        
        await db.query('COMMIT');
        
        res.json({ success: true, message: '学生删除成功' });
    } catch (error) {
        await db.query('ROLLBACK');
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router; 