const express = require('express');
const router = express.Router();
const db = require('../db');

// 获取队长队伍
router.get('/leader/:sno', async (req, res) => {
    try {
        const { sno } = req.params;
        const [team] = await db.query('SELECT * FROM team WHERE leader_sno = ?', [sno]);
        res.json({ success: true, data: team[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取队员队伍
router.get('/member/:sno', async (req, res) => {
    try {
        const { sno } = req.params;
        const [member] = await db.query('SELECT * FROM team_member WHERE sno = ?', [sno]);
        res.json({ success: true, data: member[0] });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取邀请列表
router.get('/invitations/:sno', async (req, res) => {
    try {
        const { sno } = req.params;
        
        const [invitations] = await db.query(`
            SELECT ti.*, t.team_name, s.sname as sender_name
            FROM team_invitation ti
            JOIN team t ON ti.team_id = t.team_id
            JOIN student s ON ti.sender_sno = s.sno
            WHERE ti.receiver_sno = ? AND ti.status = 'pending'
        `, [sno]);
        
        res.json({ success: true, data: invitations });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 获取队伍信息
router.get('/:team_id', async (req, res) => {
    try {
        const { team_id } = req.params;
        
        // 获取队伍基本信息
        const [team] = await db.query('SELECT * FROM team WHERE team_id = ?', [team_id]);
        if (team.length === 0) {
            return res.json({ success: false, message: '队伍不存在' });
        }
        
        // 获取队员信息
        const [members] = await db.query(`
            SELECT s.*, tm.join_time 
            FROM team_member tm 
            JOIN student s ON tm.sno = s.sno 
            WHERE tm.team_id = ?
        `, [team_id]);
        
        res.json({ 
            success: true, 
            data: {
                ...team[0],
                members
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 创建队伍
router.post('/create', async (req, res) => {
    try {
        const { team_name, leader_sno } = req.body;
        console.log('创建队伍请求:', { team_name, leader_sno });
        
        // 检查是否已经申请了课题
        const [title] = await db.query('SELECT * FROM title_select WHERE sno = ?', [leader_sno]);
        console.log('课题申请记录:', title);
        
        if (title.length === 0) {
            console.log('未找到课题申请记录');
            return res.json({ success: false, message: '请先申请课题' });
        }
        
        // 检查课题是否已批准
        if (title[0].status !== 'approved') {
            console.log('课题状态未批准:', title[0].status);
            return res.json({ success: false, message: '请等待课题申请获批后再创建队伍' });
        }
        
        // 检查是否已经创建过队伍
        const [existing] = await db.query('SELECT * FROM team WHERE leader_sno = ?', [leader_sno]);
        console.log('已存在的队伍:', existing);
        
        if (existing.length > 0) {
            return res.json({ success: false, message: '您已经创建过队伍了' });
        }
        
        // 检查是否已经加入其他队伍
        const [member] = await db.query('SELECT * FROM team_member WHERE sno = ?', [leader_sno]);
        console.log('已加入的队伍:', member);
        
        if (member.length > 0) {
            return res.json({ success: false, message: '您已经加入其他队伍了' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 创建队伍
            const [result] = await db.query('INSERT INTO team (team_name, leader_sno) VALUES (?, ?)', 
                [team_name, leader_sno]);
            
            const team_id = result.insertId;
            console.log('创建队伍成功，team_id:', team_id);
            
            // 添加队长为队员
            await db.query('INSERT INTO team_member (team_id, sno) VALUES (?, ?)', 
                [team_id, leader_sno]);
            
            await db.query('COMMIT');
            
            res.json({ success: true, message: '队伍创建成功', data: { team_id } });
        } catch (error) {
            await db.query('ROLLBACK');
            console.error('创建队伍失败:', error);
            throw error;
        }
    } catch (error) {
        console.error('创建队伍出错:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// 解散队伍
router.delete('/:team_id', async (req, res) => {
    try {
        const { team_id } = req.params;
        const { sno } = req.body;
        
        // 检查是否是队长
        const [team] = await db.query('SELECT * FROM team WHERE team_id = ? AND leader_sno = ?', [team_id, sno]);
        if (team.length === 0) {
            return res.json({ success: false, message: '只有队长可以解散队伍' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 获取队伍成员
            const [members] = await db.query('SELECT sno FROM team_member WHERE team_id = ?', [team_id]);
            
            // 获取队长的课题
            const [leaderTitle] = await db.query('SELECT titlename FROM title_select WHERE sno = ?', [sno]);
            
            if (leaderTitle.length > 0) {
                // 删除所有队员的课题申请
                for (const member of members) {
                    await db.query('DELETE FROM title_select WHERE sno = ? AND titlename = ?', 
                        [member.sno, leaderTitle[0].titlename]);
                }
                
                // 更新课题选择人数
                await db.query('UPDATE title_class SET select_no = select_no - ? WHERE titlename = ?', 
                    [members.length, leaderTitle[0].titlename]);
            }
            
            // 删除队伍相关的邀请记录
            await db.query('DELETE FROM team_invitation WHERE team_id = ?', [team_id]);
            
            // 删除队伍成员关系
            await db.query('DELETE FROM team_member WHERE team_id = ?', [team_id]);
            
            // 删除队伍
            await db.query('DELETE FROM team WHERE team_id = ?', [team_id]);
            
            await db.query('COMMIT');
            res.json({ success: true, message: '队伍解散成功' });
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 邀请队员
router.post('/invite', async (req, res) => {
    try {
        const { team_id, sender_sno, receiver_sno } = req.body;
        
        // 检查队伍是否存在
        const [team] = await db.query('SELECT * FROM team WHERE team_id = ?', [team_id]);
        if (team.length === 0) {
            return res.json({ success: false, message: '队伍不存在' });
        }
        
        // 检查发送者是否是队长
        if (team[0].leader_sno !== sender_sno) {
            return res.json({ success: false, message: '只有队长可以发送邀请' });
        }
        
        // 检查接收者是否已经加入其他队伍
        const [member] = await db.query('SELECT * FROM team_member WHERE sno = ?', [receiver_sno]);
        if (member.length > 0) {
            return res.json({ success: false, message: '该学生已经加入其他队伍' });
        }
        
        // 检查是否已经发送过邀请
        const [existing] = await db.query(`
            SELECT * FROM team_invitation 
            WHERE team_id = ? AND receiver_sno = ? AND status = 'pending'
        `, [team_id, receiver_sno]);
        
        if (existing.length > 0) {
            return res.json({ success: false, message: '已经发送过邀请了' });
        }
        
        // 发送邀请
        await db.query(`
            INSERT INTO team_invitation (team_id, sender_sno, receiver_sno) 
            VALUES (?, ?, ?)
        `, [team_id, sender_sno, receiver_sno]);
        
        res.json({ success: true, message: '邀请发送成功' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 踢出队员
router.post('/kick', async (req, res) => {
    try {
        const { team_id, leader_sno, member_sno } = req.body;
        
        // 检查是否是队长
        const [team] = await db.query('SELECT * FROM team WHERE team_id = ? AND leader_sno = ?', [team_id, leader_sno]);
        if (team.length === 0) {
            return res.json({ success: false, message: '只有队长可以踢出队员' });
        }
        
        // 检查队员是否存在
        const [member] = await db.query('SELECT * FROM team_member WHERE team_id = ? AND sno = ?', [team_id, member_sno]);
        if (member.length === 0) {
            return res.json({ success: false, message: '队员不存在' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 获取队长的课题
            const [leaderTitle] = await db.query('SELECT * FROM title_select WHERE sno = ?', [leader_sno]);
            
            // 删除队员
            await db.query('DELETE FROM team_member WHERE team_id = ? AND sno = ?', [team_id, member_sno]);
            
            // 如果队长有课题，则删除队员的课题
            if (leaderTitle.length > 0) {
                await db.query('DELETE FROM title_select WHERE sno = ? AND titlename = ?', 
                    [member_sno, leaderTitle[0].titlename]);
                
                // 更新课题选择人数
                await db.query('UPDATE title_class SET select_no = select_no - 1 WHERE titlename = ?', 
                    [leaderTitle[0].titlename]);
            }
            
            await db.query('COMMIT');
            
            res.json({ success: true, message: '踢出队员成功' });
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 退出队伍
router.post('/quit', async (req, res) => {
    try {
        const { team_id, member_sno } = req.body;
        
        // 检查是否是队长
        const [team] = await db.query('SELECT * FROM team WHERE team_id = ? AND leader_sno = ?', [team_id, member_sno]);
        if (team.length > 0) {
            return res.json({ success: false, message: '队长不能退出队伍，请先解散队伍' });
        }
        
        // 检查是否是队员
        const [member] = await db.query('SELECT * FROM team_member WHERE team_id = ? AND sno = ?', [team_id, member_sno]);
        if (member.length === 0) {
            return res.json({ success: false, message: '您不是该队伍的队员' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            // 获取队长的课题
            const [leaderTitle] = await db.query(`
                SELECT ts.* 
                FROM title_select ts 
                JOIN team t ON ts.sno = t.leader_sno 
                WHERE t.team_id = ?
            `, [team_id]);
            
            // 删除队员
            await db.query('DELETE FROM team_member WHERE team_id = ? AND sno = ?', [team_id, member_sno]);
            
            // 如果队长有课题，则删除队员的课题
            if (leaderTitle.length > 0) {
                await db.query('DELETE FROM title_select WHERE sno = ? AND titlename = ?', 
                    [member_sno, leaderTitle[0].titlename]);
                
                // 更新课题选择人数
                await db.query('UPDATE title_class SET select_no = select_no - 1 WHERE titlename = ?', 
                    [leaderTitle[0].titlename]);
            }
            
            await db.query('COMMIT');
            
            res.json({ success: true, message: '退出队伍成功' });
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// 处理邀请
router.post('/handle-invitation', async (req, res) => {
    try {
        const { invitation_id, receiver_sno, accept } = req.body;
        
        // 检查邀请是否存在
        const [invitation] = await db.query('SELECT * FROM team_invitation WHERE invitation_id = ?', [invitation_id]);
        if (invitation.length === 0) {
            return res.json({ success: false, message: '邀请不存在' });
        }
        
        // 检查是否是接收者
        if (invitation[0].receiver_sno !== receiver_sno) {
            return res.json({ success: false, message: '无权处理此邀请' });
        }
        
        // 开始事务
        await db.query('START TRANSACTION');
        
        try {
            if (accept) {
                // 获取队伍信息
                const [team] = await db.query('SELECT * FROM team WHERE team_id = ?', [invitation[0].team_id]);
                if (team.length === 0) {
                    throw new Error('队伍不存在');
                }
                
                // 获取队长的课题
                const [title] = await db.query('SELECT * FROM title_select WHERE sno = ?', [team[0].leader_sno]);
                if (title.length === 0) {
                    throw new Error('队长未选择课题');
                }
                
                // 检查队员是否已经选择了两个课题
                const [currentTitles] = await db.query('SELECT COUNT(*) as count FROM title_select WHERE sno = ?', [receiver_sno]);
                if (currentTitles[0].count >= 2) {
                    throw new Error('您已经选择了两个课题，无法加入队伍');
                }
                
                // 检查队员是否已经选择了该课题
                const [existing] = await db.query('SELECT * FROM title_select WHERE sno = ? AND titlename = ?', 
                    [receiver_sno, title[0].titlename]);
                if (existing.length > 0) {
                    throw new Error('您已经选择了该课题');
                }
                
                // 接受邀请
                await db.query('UPDATE team_invitation SET status = "accepted" WHERE invitation_id = ?', [invitation_id]);
                
                // 添加为队员
                await db.query('INSERT INTO team_member (team_id, sno) VALUES (?, ?)', 
                    [invitation[0].team_id, receiver_sno]);
                
                // 自动选择队长的课题
                await db.query('INSERT INTO title_select (sno, titlename, status) VALUES (?, ?, ?)', 
                    [receiver_sno, title[0].titlename, title[0].status]);
                
                // 更新课题选择人数
                await db.query('UPDATE title_class SET select_no = select_no + 1 WHERE titlename = ?', 
                    [title[0].titlename]);
            } else {
                // 拒绝邀请
                await db.query('UPDATE team_invitation SET status = "rejected" WHERE invitation_id = ?', [invitation_id]);
            }
            
            await db.query('COMMIT');
            
            res.json({ success: true, message: accept ? '已接受邀请' : '已拒绝邀请' });
        } catch (error) {
            await db.query('ROLLBACK');
            throw error;
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

module.exports = router; 