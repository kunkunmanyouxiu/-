const mysql = require('mysql2/promise');

// 创建连接池
const pool = mysql.createPool({
    host: 'sh-cynosdbmysql-grp-j73eq302.sql.tencentcdb.com',
    port: 27577,

    user: 'root',
    password: '20040622Rsk',
    database: 'select_class',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

module.exports = pool; 